"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Camera, X, Plus, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"

export default function AddProductPage() {
  const router = useRouter()
  const [images, setImages] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedSubCategory, setSelectedSubCategory] = useState("")
  const [specifications, setSpecifications] = useState<{ key: string; value: string }[]>([])
  const [showImageSourceDialog, setShowImageSourceDialog] = useState(false)

  // Specification templates based on category
  const categorySpecifications: Record<string, { key: string; label: string }[]> = {
    electronics: [
      { key: "brand", label: "Brand" },
      { key: "model", label: "Model" },
      { key: "warranty", label: "Warranty" },
      { key: "condition", label: "Condition" },
      { key: "color", label: "Color" },
    ],
    fashion: [
      { key: "brand", label: "Brand" },
      { key: "size", label: "Size" },
      { key: "color", label: "Color" },
      { key: "material", label: "Material" },
      { key: "gender", label: "Gender" },
    ],
    "home-appliances": [
      { key: "brand", label: "Brand" },
      { key: "model", label: "Model" },
      { key: "powerConsumption", label: "Power Consumption" },
      { key: "warranty", label: "Warranty" },
      { key: "dimensions", label: "Dimensions" },
    ],
    beauty: [
      { key: "brand", label: "Brand" },
      { key: "skinType", label: "Suitable Skin Type" },
      { key: "ingredients", label: "Key Ingredients" },
      { key: "expiryDate", label: "Expiry Date" },
      { key: "volume", label: "Volume/Weight" },
    ],
    phones: [
      { key: "brand", label: "Brand" },
      { key: "model", label: "Model" },
      { key: "storage", label: "Storage Capacity" },
      { key: "ram", label: "RAM" },
      { key: "screenSize", label: "Screen Size" },
      { key: "camera", label: "Camera" },
      { key: "battery", label: "Battery" },
    ],
  }

  // Subcategories based on main category
  const categorySubcategories: Record<string, string[]> = {
    electronics: ["TVs", "Audio", "Cameras", "Wearables", "Gaming"],
    fashion: ["Men's Clothing", "Women's Clothing", "Kids' Clothing", "Footwear", "Accessories"],
    "home-appliances": ["Kitchen", "Laundry", "Cleaning", "Cooling & Heating", "Small Appliances"],
    beauty: ["Skincare", "Makeup", "Haircare", "Fragrances", "Bath & Body"],
    phones: ["Smartphones", "Tablets", "Accessories", "Cases & Covers", "Screen Protectors"],
  }

  useEffect(() => {
    if (selectedCategory) {
      const specs = categorySpecifications[selectedCategory] || []
      setSpecifications(specs.map((spec) => ({ key: spec.key, value: "" })))
    } else {
      setSpecifications([])
    }
  }, [selectedCategory])

  const handleAddImage = () => {
    setShowImageSourceDialog(true)
  }

  const handleImageFromCamera = () => {
    // In a real app, this would open the device's camera
    alert("In a real app, this would open your device's camera")
    setShowImageSourceDialog(false)

    // Simulate adding an image
    setImages([...images, "/placeholder.svg?height=300&width=300&text=Camera+Image"])
  }

  const handleImageFromGallery = () => {
    // In a real app, this would open the device's gallery
    alert("In a real app, this would open your device's gallery")
    setShowImageSourceDialog(false)

    // Simulate adding an image
    setImages([...images, "/placeholder.svg?height=300&width=300&text=Gallery+Image"])
  }

  const handleRemoveImage = (index: number) => {
    const newImages = [...images]
    newImages.splice(index, 1)
    setImages(newImages)
  }

  const handleSpecificationChange = (index: number, value: string) => {
    const newSpecs = [...specifications]
    newSpecs[index].value = value
    setSpecifications(newSpecs)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      router.push("/account/sell-on-ramsphere?success=true")
    }, 1500)
  }

  const categories = [
    "fashion",
    "electronics",
    "home-appliances",
    "beauty",
    "groceries",
    "phones",
    "computers",
    "other",
  ]

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-[#40E0D0] shadow-sm">
        <div className="px-4 py-3">
          <div className="flex items-center">
            <Link href="/account/sell-on-ramsphere" className="flex items-center">
              <ArrowLeft className="h-5 w-5 text-white mr-2" />
              <span className="text-white font-bold text-lg">Add Product</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="flex-1 p-4 pb-16">
        <form onSubmit={handleSubmit}>
          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="font-medium mb-4">Product Images</h2>

            <div className="grid grid-cols-3 gap-3 mb-4">
              {images.map((image, index) => (
                <div key={index} className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden">
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`Product image ${index + 1}`}
                    fill
                    className="object-cover"
                  />
                  <button
                    type="button"
                    className="absolute top-1 right-1 bg-white rounded-full p-1"
                    onClick={() => handleRemoveImage(index)}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}

              {images.length < 6 && (
                <button
                  type="button"
                  className="aspect-square bg-gray-100 rounded-lg flex flex-col items-center justify-center"
                  onClick={handleAddImage}
                >
                  <Plus className="h-6 w-6 text-gray-400 mb-1" />
                  <span className="text-xs text-gray-500">Add Image</span>
                </button>
              )}
            </div>

            <p className="text-xs text-gray-500">You can add up to 6 images. First image will be the cover image.</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="font-medium mb-4">Product Information</h2>

            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Product Name</Label>
                <Input id="name" placeholder="Enter product name" required />
              </div>

              <div>
                <Label htmlFor="category">Category</Label>
                <Select onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category.charAt(0).toUpperCase() + category.slice(1).replace("-", " ")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedCategory && categorySubcategories[selectedCategory] && (
                <div>
                  <Label htmlFor="subcategory">Subcategory</Label>
                  <Select onValueChange={setSelectedSubCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select subcategory" />
                    </SelectTrigger>
                    <SelectContent>
                      {categorySubcategories[selectedCategory].map((subcategory) => (
                        <SelectItem key={subcategory} value={subcategory.toLowerCase().replace(/\s+/g, "-")}>
                          {subcategory}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" placeholder="Describe your product" rows={4} required />
              </div>
            </div>
          </div>

          {selectedCategory && specifications.length > 0 && (
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h2 className="font-medium mb-4">Product Specifications</h2>

              <div className="space-y-4">
                {specifications.map((spec, index) => {
                  const specDefinition = categorySpecifications[selectedCategory].find((s) => s.key === spec.key)
                  return (
                    <div key={spec.key}>
                      <Label htmlFor={`spec-${spec.key}`}>{specDefinition?.label}</Label>
                      <Input
                        id={`spec-${spec.key}`}
                        placeholder={`Enter ${specDefinition?.label.toLowerCase()}`}
                        value={spec.value}
                        onChange={(e) => handleSpecificationChange(index, e.target.value)}
                      />
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="font-medium mb-4">Pricing & Inventory</h2>

            <div className="space-y-4">
              <div>
                <Label htmlFor="price">Price ($)</Label>
                <Input id="price" type="number" min="0.01" step="0.01" placeholder="0.00" required />
              </div>

              <div>
                <Label htmlFor="comparePrice">Compare-at Price ($) (Optional)</Label>
                <Input id="comparePrice" type="number" min="0.01" step="0.01" placeholder="0.00" />
                <p className="text-xs text-gray-500 mt-1">
                  To show a markdown, enter a price higher than your selling price
                </p>
              </div>

              <div>
                <Label htmlFor="quantity">Quantity</Label>
                <Input id="quantity" type="number" min="1" step="1" placeholder="1" required />
              </div>

              <div>
                <Label htmlFor="sku">SKU (Optional)</Label>
                <Input id="sku" placeholder="SKU" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="font-medium mb-4">Shipping</h2>

            <div className="space-y-4">
              <div>
                <Label htmlFor="weight">Weight (kg)</Label>
                <Input id="weight" type="number" min="0.01" step="0.01" placeholder="0.00" required />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label htmlFor="length">Length (cm)</Label>
                  <Input id="length" type="number" min="0.1" step="0.1" placeholder="0.0" required />
                </div>
                <div>
                  <Label htmlFor="width">Width (cm)</Label>
                  <Input id="width" type="number" min="0.1" step="0.1" placeholder="0.0" required />
                </div>
                <div>
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input id="height" type="number" min="0.1" step="0.1" placeholder="0.0" required />
                </div>
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full bg-[#DEA818] hover:bg-[#c99616]" disabled={isSubmitting}>
            {isSubmitting ? "Submitting..." : "Add Product"}
          </Button>
        </form>
      </div>

      {/* Image Source Dialog */}
      {showImageSourceDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-xs overflow-hidden">
            <div className="p-4">
              <h3 className="text-lg font-medium mb-4 text-center">Select Image Source</h3>

              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  className="flex flex-col items-center justify-center bg-gray-100 p-4 rounded-lg"
                  onClick={handleImageFromCamera}
                >
                  <Camera className="h-8 w-8 text-[#DEA818] mb-2" />
                  <span>Camera</span>
                </button>

                <button
                  type="button"
                  className="flex flex-col items-center justify-center bg-gray-100 p-4 rounded-lg"
                  onClick={handleImageFromGallery}
                >
                  <Upload className="h-8 w-8 text-[#DEA818] mb-2" />
                  <span>Gallery</span>
                </button>
              </div>

              <button
                type="button"
                className="w-full mt-4 p-2 border border-gray-300 rounded-lg text-center"
                onClick={() => setShowImageSourceDialog(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

