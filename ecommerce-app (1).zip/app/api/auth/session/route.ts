import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { verifyToken, getUserById } from "@/lib/auth"

export async function GET() {
  try {
    // Get token from cookies
    const cookieStore = cookies()
    const token = cookieStore.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ user: null })
    }

    // Verify token
    const decoded = verifyToken(token)

    if (!decoded || !decoded.id) {
      return NextResponse.json({ user: null })
    }

    // Get user from database
    const user = await getUserById(decoded.id)

    if (!user) {
      return NextResponse.json({ user: null })
    }

    // Return user without sensitive information
    return NextResponse.json({
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
      },
    })
  } catch (error) {
    console.error("Session error:", error)
    return NextResponse.json({ user: null })
  }
}

