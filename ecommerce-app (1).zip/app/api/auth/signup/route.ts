import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { createUser, createToken } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    const { username, email, password } = await request.json()

    // Validate input
    if (!username || !email || !password) {
      return NextResponse.json({ error: "Username, email, and password are required" }, { status: 400 })
    }

    // Create user
    const user = await createUser({ username, email, password })

    // Create token
    const token = createToken({ id: user._id.toString() })

    // Set cookie
    cookies().set({
      name: "auth-token",
      value: token,
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 1 week
    })

    return NextResponse.json({ user })
  } catch (error) {
    console.error("Sign up error:", error)

    if (error.message === "User already exists") {
      return NextResponse.json({ error: "Email already in use" }, { status: 409 })
    }

    return NextResponse.json({ error: "An error occurred during sign up" }, { status: 500 })
  }
}

