import { NextResponse } from "next/server"
import OpenAI from "openai"

// Initialize OpenAI client with the API key
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(request: Request) {
  try {
    // Check if API key is configured
    if (!openai.apiKey) {
      return NextResponse.json({ error: "OpenAI API key not configured" }, { status: 500 })
    }

    // Parse request body
    const body = await request.json()
    const { messages } = body

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "Invalid request format" }, { status: 400 })
    }

    // Create chat completion
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content:
            "You are a helpful shopping assistant for RamSphere e-commerce platform. Provide concise and helpful responses to customer inquiries.",
        },
        ...messages,
      ],
      max_tokens: 150,
      temperature: 0.7,
    })

    // Extract and return the response
    const message = completion.choices[0].message.content || "I'm sorry, I couldn't process your request."

    return NextResponse.json({ message })
  } catch (error: any) {
    console.error("Error in chat API:", error)

    // Handle different types of errors
    if (error.response) {
      console.error(error.response.status, error.response.data)
      return NextResponse.json({ error: error.response.data }, { status: error.response.status })
    } else {
      return NextResponse.json({ error: "An error occurred during your request." }, { status: 500 })
    }
  }
}

