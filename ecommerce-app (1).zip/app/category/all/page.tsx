"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import MobileNavigation from "@/components/mobile-navigation"
import { useRouter } from "next/navigation"

export default function AllCategoriesPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("categories")

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    if (tab === "home") {
      router.push("/")
    } else if (tab === "cart") {
      router.push("/cart")
    } else if (tab === "account") {
      router.push("/account")
    } else if (tab === "help") {
      router.push("/help")
    }
  }

  // Update the categories array to include all the categories we've created
  const categories = [
    {
      name: "FoodMart",
      image: "/placeholder.svg?height=300&width=300&text=FoodMart",
      path: "/category/foodmart",
    },
    {
      name: "BeautyCare",
      image: "/placeholder.svg?height=300&width=300&text=BeautyCare",
      path: "/category/beautycare",
    },
    {
      name: "Home & Office",
      image: "/placeholder.svg?height=300&width=300&text=Home+Office",
      path: "/category/home-office",
    },
    {
      name: "Phones & Tablets",
      image: "/placeholder.svg?height=300&width=300&text=Phones+Tablets",
      path: "/category/phones-tablets",
    },
    {
      name: "Computers & Peripherals",
      image: "/placeholder.svg?height=300&width=300&text=Computers+Peripherals",
      path: "/category/computers-peripherals",
    },
    {
      name: "Electronics",
      image: "/placeholder.svg?height=300&width=300&text=Electronics",
      path: "/category/electronics",
    },
    {
      name: "Fashion",
      image: "/placeholder.svg?height=300&width=300&text=Fashion",
      path: "/category/fashion",
    },
    {
      name: "Game Hub",
      image: "/placeholder.svg?height=300&width=300&text=Game+Hub",
      path: "/category/game-hub",
    },
    {
      name: "Infant Care",
      image: "/placeholder.svg?height=300&width=300&text=Infant+Care",
      path: "/category/infant-care",
    },
    {
      name: "Pet Care",
      image: "/placeholder.svg?height=300&width=300&text=Pet+Care",
      path: "/category/pet-care",
    },
    {
      name: "Sports Gears",
      image: "/placeholder.svg?height=300&width=300&text=Sports+Gears",
      path: "/category/sports-gears",
    },
    {
      name: "Automobile",
      image: "/placeholder.svg?height=300&width=300&text=Automobile",
      path: "/category/automobile",
    },
    {
      name: "Garden & Patio",
      image: "/placeholder.svg?height=300&width=300&text=Garden+Patio",
      path: "/category/garden-patio",
    },
    {
      name: "Entertainment & Media",
      image: "/placeholder.svg?height=300&width=300&text=Entertainment+Media",
      path: "/category/entertainment-media",
    },
    {
      name: "Industrial Tech",
      image: "/placeholder.svg?height=300&width=300&text=Industrial+Tech",
      path: "/category/industrial-tech",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-[#40E0D0] shadow-sm">
        <div className="px-4 py-3">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <ArrowLeft className="h-5 w-5 text-white mr-2" />
              <span className="text-white font-bold text-lg">All Categories</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="flex-1 p-4 pb-16">
        <div className="grid grid-cols-3 gap-3">
          {categories.map((category) => (
            <Link
              href={category.path}
              key={category.name}
              className="flex flex-col items-center bg-white rounded-lg p-3 shadow-sm"
            >
              <div className="relative h-16 w-16 bg-[#B6EDE7] rounded-full mb-2 flex items-center justify-center overflow-hidden">
                <Image src={category.image || "/placeholder.svg"} alt={category.name} fill className="object-cover" />
              </div>
              <span className="text-xs font-medium text-center">{category.name}</span>
            </Link>
          ))}
        </div>
      </div>

      <MobileNavigation activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  )
}

