"use client"

import CategoryPage from "@/components/category-page"

export default function AutomobilePage() {
  // Sample product data for Automobile
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 1101,
          name: "Car Battery",
          image: "/placeholder.svg?height=300&width=300&text=Car+Battery",
          price: "$129.99",
        },
        {
          id: 1102,
          name: "Motor Oil",
          image: "/placeholder.svg?height=300&width=300&text=Motor+Oil",
          price: "$24.99",
        },
        {
          id: 1103,
          name: "Car Cover",
          image: "/placeholder.svg?height=300&width=300&text=Car+Cover",
          price: "$49.99",
        },
      ],
    },
    {
      category: "Car Parts",
      items: [
        {
          id: 1104,
          name: "Car Battery",
          image: "/placeholder.svg?height=300&width=300&text=Car+Battery",
          price: "$129.99",
        },
        {
          id: 1105,
          name: "Brake Pads",
          image: "/placeholder.svg?height=300&width=300&text=Brake+Pads",
          price: "$39.99",
        },
        {
          id: 1106,
          name: "Air Filter",
          image: "/placeholder.svg?height=300&width=300&text=Air+Filter",
          price: "$14.99",
        },
        {
          id: 1107,
          name: "Spark Plugs",
          image: "/placeholder.svg?height=300&width=300&text=Spark+Plugs",
          price: "$9.99",
        },
        {
          id: 1108,
          name: "Alternator",
          image: "/placeholder.svg?height=300&width=300&text=Alternator",
          price: "$149.99",
        },
        {
          id: 1109,
          name: "Radiator",
          image: "/placeholder.svg?height=300&width=300&text=Radiator",
          price: "$89.99",
        },
      ],
    },
    {
      category: "Fluids & Oils",
      items: [
        {
          id: 1110,
          name: "Motor Oil",
          image: "/placeholder.svg?height=300&width=300&text=Motor+Oil",
          price: "$24.99",
        },
        {
          id: 1111,
          name: "Transmission Fluid",
          image: "/placeholder.svg?height=300&width=300&text=Transmission+Fluid",
          price: "$19.99",
        },
        {
          id: 1112,
          name: "Brake Fluid",
          image: "/placeholder.svg?height=300&width=300&text=Brake+Fluid",
          price: "$12.99",
        },
        {
          id: 1113,
          name: "Coolant",
          image: "/placeholder.svg?height=300&width=300&text=Coolant",
          price: "$14.99",
        },
        {
          id: 1114,
          name: "Power Steering Fluid",
          image: "/placeholder.svg?height=300&width=300&text=Power+Steering+Fluid",
          price: "$9.99",
        },
        {
          id: 1115,
          name: "Windshield Washer Fluid",
          image: "/placeholder.svg?height=300&width=300&text=Washer+Fluid",
          price: "$4.99",
        },
      ],
    },
    {
      category: "Car Accessories",
      items: [
        {
          id: 1116,
          name: "Car Cover",
          image: "/placeholder.svg?height=300&width=300&text=Car+Cover",
          price: "$49.99",
        },
        {
          id: 1117,
          name: "Floor Mats",
          image: "/placeholder.svg?height=300&width=300&text=Floor+Mats",
          price: "$29.99",
        },
        {
          id: 1118,
          name: "Seat Covers",
          image: "/placeholder.svg?height=300&width=300&text=Seat+Covers",
          price: "$39.99",
        },
        {
          id: 1119,
          name: "Steering Wheel Cover",
          image: "/placeholder.svg?height=300&width=300&text=Steering+Wheel+Cover",
          price: "$19.99",
        },
        {
          id: 1120,
          name: "Car Phone Mount",
          image: "/placeholder.svg?height=300&width=300&text=Phone+Mount",
          price: "$14.99",
        },
        {
          id: 1121,
          name: "Dash Cam",
          image: "/placeholder.svg?height=300&width=300&text=Dash+Cam",
          price: "$79.99",
        },
      ],
    },
    {
      category: "Tools & Equipment",
      items: [
        {
          id: 1122,
          name: "Jack Stand",
          image: "/placeholder.svg?height=300&width=300&text=Jack+Stand",
          price: "$49.99",
        },
        {
          id: 1123,
          name: "Tire Pressure Gauge",
          image: "/placeholder.svg?height=300&width=300&text=Pressure+Gauge",
          price: "$9.99",
        },
        {
          id: 1124,
          name: "Jump Starter",
          image: "/placeholder.svg?height=300&width=300&text=Jump+Starter",
          price: "$69.99",
        },
        {
          id: 1125,
          name: "OBD2 Scanner",
          image: "/placeholder.svg?height=300&width=300&text=OBD2+Scanner",
          price: "$59.99",
        },
        {
          id: 1126,
          name: "Socket Set",
          image: "/placeholder.svg?height=300&width=300&text=Socket+Set",
          price: "$39.99",
        },
        {
          id: 1127,
          name: "Car Vacuum",
          image: "/placeholder.svg?height=300&width=300&text=Car+Vacuum",
          price: "$29.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Automobile" products={products} />
}

