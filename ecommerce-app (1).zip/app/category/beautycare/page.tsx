"use client"

import CategoryPage from "@/components/category-page"

export default function BeautyCarePage() {
  // Sample product data for BeautyCare
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 201,
          name: "Face Cream",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$19.99",
        },
        {
          id: 202,
          name: "Lipstick",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$12.99",
        },
        {
          id: 203,
          name: "Perfume",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$49.99",
        },
      ],
    },
    {
      category: "Skin Care",
      items: [
        {
          id: 204,
          name: "Face Cream",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$19.99",
        },
        {
          id: 205,
          name: "Face Wash",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$14.99",
        },
        {
          id: 206,
          name: "Serum",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$29.99",
        },
        {
          id: 207,
          name: "Moisturizer",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$24.99",
        },
        {
          id: 208,
          name: "Sunscreen",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$15.99",
        },
        {
          id: 209,
          name: "Face Mask",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$9.99",
        },
      ],
    },
    {
      category: "Makeup",
      items: [
        {
          id: 210,
          name: "Lipstick",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$12.99",
        },
        {
          id: 211,
          name: "Foundation",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$24.99",
        },
        {
          id: 212,
          name: "Mascara",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$14.99",
        },
        {
          id: 213,
          name: "Eyeshadow",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$19.99",
        },
        {
          id: 214,
          name: "Blush",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$16.99",
        },
        {
          id: 215,
          name: "Concealer",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$17.99",
        },
      ],
    },
    {
      category: "Fragrances",
      items: [
        {
          id: 216,
          name: "Perfume",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$49.99",
        },
        {
          id: 217,
          name: "Body Spray",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$19.99",
        },
        {
          id: 218,
          name: "Cologne",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$39.99",
        },
        {
          id: 219,
          name: "Deodorant",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$9.99",
        },
        {
          id: 220,
          name: "Body Mist",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$14.99",
        },
        {
          id: 221,
          name: "Aftershave",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$24.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="BeautyCare" products={products} />
}

