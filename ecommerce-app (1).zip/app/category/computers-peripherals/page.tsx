"use client"

import CategoryPage from "@/components/category-page"

export default function ComputersPeripheralsPage() {
  // Sample product data for Computers & Peripherals
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 501,
          name: "Laptop",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
          price: "$799.99",
        },
        {
          id: 502,
          name: "Monitor",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$199.99",
        },
        {
          id: 503,
          name: "Keyboard",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$49.99",
        },
      ],
    },
    {
      category: "Laptops",
      items: [
        {
          id: 504,
          name: "MacBook",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
          price: "$1299.99",
        },
        {
          id: 505,
          name: "Dell XPS",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
          price: "$999.99",
        },
        {
          id: 506,
          name: "HP Spectre",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
          price: "$899.99",
        },
        {
          id: 507,
          name: "Lenovo ThinkPad",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
          price: "$799.99",
        },
        {
          id: 508,
          name: "Asus ZenBook",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
          price: "$849.99",
        },
        {
          id: 509,
          name: "Acer Swift",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
          price: "$699.99",
        },
      ],
    },
    {
      category: "Desktops",
      items: [
        {
          id: 510,
          name: "iMac",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$1499.99",
        },
        {
          id: 511,
          name: "Dell Inspiron",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$699.99",
        },
        {
          id: 512,
          name: "HP Pavilion",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$599.99",
        },
        {
          id: 513,
          name: "Lenovo IdeaCentre",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$649.99",
        },
        {
          id: 514,
          name: "Asus ROG",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$1299.99",
        },
        {
          id: 515,
          name: "Acer Aspire",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$549.99",
        },
      ],
    },
    {
      category: "Peripherals",
      items: [
        {
          id: 516,
          name: "Monitor",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$199.99",
        },
        {
          id: 517,
          name: "Keyboard",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$49.99",
        },
        {
          id: 518,
          name: "Mouse",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$29.99",
        },
        {
          id: 519,
          name: "Printer",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$149.99",
        },
        {
          id: 520,
          name: "External Hard Drive",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$79.99",
        },
        {
          id: 521,
          name: "Webcam",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$59.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Computers & Peripherals" products={products} />
}

