"use client"

import CategoryPage from "@/components/category-page"

export default function ElectronicsPage() {
  // Sample product data for Electronics
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 601,
          name: "Washing Machine",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.14.53-firaaQh1drI3JIje93XnpN14z4gsIe.png",
          price: "$499.99",
        },
        {
          id: 602,
          name: "Refrigerator",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$899.99",
        },
        {
          id: 603,
          name: "Microwave",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.14.53-firaaQh1drI3JIje93XnpN14z4gsIe.png",
          price: "$149.99",
        },
      ],
    },
    {
      category: "Home Appliances",
      items: [
        {
          id: 604,
          name: "Washing Machine",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.14.53-firaaQh1drI3JIje93XnpN14z4gsIe.png",
          price: "$499.99",
        },
        {
          id: 605,
          name: "Refrigerator",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$899.99",
        },
        {
          id: 606,
          name: "Microwave",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.14.53-firaaQh1drI3JIje93XnpN14z4gsIe.png",
          price: "$149.99",
        },
        {
          id: 607,
          name: "Dishwasher",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.14.53-firaaQh1drI3JIje93XnpN14z4gsIe.png",
          price: "$399.99",
        },
        {
          id: 608,
          name: "Air Conditioner",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$549.99",
        },
        {
          id: 609,
          name: "Vacuum Cleaner",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.14.53-firaaQh1drI3JIje93XnpN14z4gsIe.png",
          price: "$199.99",
        },
      ],
    },
    {
      category: "TV & Audio",
      items: [
        {
          id: 610,
          name: "Smart TV",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$699.99",
        },
        {
          id: 611,
          name: "Soundbar",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$199.99",
        },
        {
          id: 612,
          name: "Bluetooth Speaker",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$89.99",
        },
        {
          id: 613,
          name: "Home Theater",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$399.99",
        },
        {
          id: 614,
          name: "Headphones",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$129.99",
        },
        {
          id: 615,
          name: "Media Player",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$79.99",
        },
      ],
    },
    {
      category: "Kitchen Appliances",
      items: [
        {
          id: 616,
          name: "Blender",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$79.99",
        },
        {
          id: 617,
          name: "Coffee Maker",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$99.99",
        },
        {
          id: 618,
          name: "Toaster",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$49.99",
        },
        {
          id: 619,
          name: "Food Processor",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$129.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Electronics" products={products} />
}

