"use client"

import CategoryPage from "@/components/category-page"

export default function EntertainmentMediaPage() {
  // Sample product data for Entertainment & Media
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 201,
          name: "Sony WH-1000XM5 Headphones",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$349.99",
        },
        {
          id: 202,
          name: "Samsung 55-inch Smart TV",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$799.99",
        },
        {
          id: 203,
          name: "Apple iPad Pro 11-inch",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$999.99",
        },
      ],
    },
    {
      category: "Gaming",
      items: [
        {
          id: 204,
          name: "PlayStation 5",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$499.99",
        },
        {
          id: 205,
          name: "Xbox Series X",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$499.99",
        },
        {
          id: 206,
          name: "Nintendo Switch OLED",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$349.99",
        },
      ],
    },
    {
      category: "Music & Audio",
      items: [
        {
          id: 207,
          name: "Bose SoundLink Bluetooth Speaker",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$129.99",
        },
        {
          id: 208,
          name: "JBL PartyBox 310",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$499.99",
        },
        {
          id: 209,
          name: "Apple AirPods Pro",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$249.99",
        },
      ],
    },
    {
      category: "Movies & TV Shows",
      items: [
        {
          id: 210,
          name: "Stranger Things (Blu-ray)",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$24.99",
        },
        {
          id: 211,
          name: "Game of Thrones Complete Series",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$129.99",
        },
        {
          id: 212,
          name: "Marvel Avengers Box Set",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$89.99",
        },
      ],
    },
    {
      category: "Books & Magazines",
      items: [
        {
          id: 213,
          name: "Atomic Habits - James Clear",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$15.99",
        },
        {
          id: 214,
          name: "Harry Potter Complete Set",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$99.99",
        },
        {
          id: 215,
          name: "Forbes Magazine (Annual Subscription)",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$49.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Entertainment & Media" products={products} />
}

