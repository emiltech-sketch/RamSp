"use client"

import CategoryPage from "@/components/category-page"

export default function FashionPage() {
  // Sample product data for Fashion
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 1301,
          name: "Men's T-Shirt",
          image: "/placeholder.svg?height=300&width=300&text=Men's+T-Shirt",
          price: "$19.99",
        },
        {
          id: 1302,
          name: "Women's Dress",
          image: "/placeholder.svg?height=300&width=300&text=Women's+Dress",
          price: "$49.99",
        },
        {
          id: 1303,
          name: "Sneakers",
          image: "/placeholder.svg?height=300&width=300&text=Sneakers",
          price: "$79.99",
        },
      ],
    },
    {
      category: "Men's Clothing",
      items: [
        {
          id: 1304,
          name: "Men's T-Shirt",
          image: "/placeholder.svg?height=300&width=300&text=Men's+T-Shirt",
          price: "$19.99",
        },
        {
          id: 1305,
          name: "Men's Jeans",
          image: "/placeholder.svg?height=300&width=300&text=Men's+Jeans",
          price: "$39.99",
        },
        {
          id: 1306,
          name: "Men's Hoodie",
          image: "/placeholder.svg?height=300&width=300&text=Men's+Hoodie",
          price: "$34.99",
        },
        {
          id: 1307,
          name: "Men's Dress Shirt",
          image: "/placeholder.svg?height=300&width=300&text=Dress+Shirt",
          price: "$29.99",
        },
        {
          id: 1308,
          name: "Men's Shorts",
          image: "/placeholder.svg?height=300&width=300&text=Men's+Shorts",
          price: "$24.99",
        },
        {
          id: 1309,
          name: "Men's Jacket",
          image: "/placeholder.svg?height=300&width=300&text=Men's+Jacket",
          price: "$59.99",
        },
      ],
    },
    {
      category: "Women's Clothing",
      items: [
        {
          id: 1310,
          name: "Women's Dress",
          image: "/placeholder.svg?height=300&width=300&text=Women's+Dress",
          price: "$49.99",
        },
        {
          id: 1311,
          name: "Women's Blouse",
          image: "/placeholder.svg?height=300&width=300&text=Women's+Blouse",
          price: "$29.99",
        },
        {
          id: 1312,
          name: "Women's Jeans",
          image: "/placeholder.svg?height=300&width=300&text=Women's+Jeans",
          price: "$39.99",
        },
        {
          id: 1313,
          name: "Women's Skirt",
          image: "/placeholder.svg?height=300&width=300&text=Women's+Skirt",
          price: "$34.99",
        },
        {
          id: 1314,
          name: "Women's Sweater",
          image: "/placeholder.svg?height=300&width=300&text=Women's+Sweater",
          price: "$44.99",
        },
        {
          id: 1315,
          name: "Women's Jacket",
          image: "/placeholder.svg?height=300&width=300&text=Women's+Jacket",
          price: "$69.99",
        },
      ],
    },
    {
      category: "Footwear",
      items: [
        {
          id: 1316,
          name: "Sneakers",
          image: "/placeholder.svg?height=300&width=300&text=Sneakers",
          price: "$79.99",
        },
        {
          id: 1317,
          name: "Dress Shoes",
          image: "/placeholder.svg?height=300&width=300&text=Dress+Shoes",
          price: "$89.99",
        },
        {
          id: 1318,
          name: "Sandals",
          image: "/placeholder.svg?height=300&width=300&text=Sandals",
          price: "$29.99",
        },
        {
          id: 1319,
          name: "Boots",
          image: "/placeholder.svg?height=300&width=300&text=Boots",
          price: "$99.99",
        },
        {
          id: 1320,
          name: "Slippers",
          image: "/placeholder.svg?height=300&width=300&text=Slippers",
          price: "$19.99",
        },
        {
          id: 1321,
          name: "Athletic Shoes",
          image: "/placeholder.svg?height=300&width=300&text=Athletic+Shoes",
          price: "$69.99",
        },
      ],
    },
    {
      category: "Accessories",
      items: [
        {
          id: 1322,
          name: "Watches",
          image: "/placeholder.svg?height=300&width=300&text=Watches",
          price: "$99.99",
        },
        {
          id: 1323,
          name: "Sunglasses",
          image: "/placeholder.svg?height=300&width=300&text=Sunglasses",
          price: "$29.99",
        },
        {
          id: 1324,
          name: "Handbags",
          image: "/placeholder.svg?height=300&width=300&text=Handbags",
          price: "$59.99",
        },
        {
          id: 1325,
          name: "Belts",
          image: "/placeholder.svg?height=300&width=300&text=Belts",
          price: "$24.99",
        },
        {
          id: 1326,
          name: "Jewelry",
          image: "/placeholder.svg?height=300&width=300&text=Jewelry",
          price: "$39.99",
        },
        {
          id: 1327,
          name: "Hats",
          image: "/placeholder.svg?height=300&width=300&text=Hats",
          price: "$19.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Fashion" products={products} />
}

