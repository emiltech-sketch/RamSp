"use client"

import CategoryPage from "@/components/category-page"

export default function GameHubPage() {
  // Sample product data for Game Hub
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 701,
          name: "PlayStation 5",
          image: "/placeholder.svg?height=300&width=300&text=PS5",
          price: "$499.99",
        },
        {
          id: 702,
          name: "Xbox Series X",
          image: "/placeholder.svg?height=300&width=300&text=Xbox",
          price: "$499.99",
        },
        {
          id: 703,
          name: "Nintendo Switch",
          image: "/placeholder.svg?height=300&width=300&text=Switch",
          price: "$299.99",
        },
      ],
    },
    {
      category: "Consoles",
      items: [
        {
          id: 704,
          name: "PlayStation 5",
          image: "/placeholder.svg?height=300&width=300&text=PS5",
          price: "$499.99",
        },
        {
          id: 705,
          name: "PlayStation 5 Digital",
          image: "/placeholder.svg?height=300&width=300&text=PS5+Digital",
          price: "$399.99",
        },
        {
          id: 706,
          name: "Xbox Series X",
          image: "/placeholder.svg?height=300&width=300&text=Xbox+X",
          price: "$499.99",
        },
        {
          id: 707,
          name: "Xbox Series S",
          image: "/placeholder.svg?height=300&width=300&text=Xbox+S",
          price: "$299.99",
        },
        {
          id: 708,
          name: "Nintendo Switch",
          image: "/placeholder.svg?height=300&width=300&text=Switch",
          price: "$299.99",
        },
        {
          id: 709,
          name: "Nintendo Switch Lite",
          image: "/placeholder.svg?height=300&width=300&text=Switch+Lite",
          price: "$199.99",
        },
      ],
    },
    {
      category: "Games",
      items: [
        {
          id: 710,
          name: "The Legend of Zelda",
          image: "/placeholder.svg?height=300&width=300&text=Zelda",
          price: "$59.99",
        },
        {
          id: 711,
          name: "Call of Duty",
          image: "/placeholder.svg?height=300&width=300&text=COD",
          price: "$69.99",
        },
        {
          id: 712,
          name: "FIFA 24",
          image: "/placeholder.svg?height=300&width=300&text=FIFA",
          price: "$59.99",
        },
        {
          id: 713,
          name: "Minecraft",
          image: "/placeholder.svg?height=300&width=300&text=Minecraft",
          price: "$29.99",
        },
        {
          id: 714,
          name: "Grand Theft Auto V",
          image: "/placeholder.svg?height=300&width=300&text=GTA",
          price: "$39.99",
        },
        {
          id: 715,
          name: "Assassin's Creed",
          image: "/placeholder.svg?height=300&width=300&text=AC",
          price: "$49.99",
        },
      ],
    },
    {
      category: "Accessories",
      items: [
        {
          id: 716,
          name: "PS5 Controller",
          image: "/placeholder.svg?height=300&width=300&text=PS5+Controller",
          price: "$69.99",
        },
        {
          id: 717,
          name: "Xbox Controller",
          image: "/placeholder.svg?height=300&width=300&text=Xbox+Controller",
          price: "$59.99",
        },
        {
          id: 718,
          name: "Gaming Headset",
          image: "/placeholder.svg?height=300&width=300&text=Headset",
          price: "$99.99",
        },
        {
          id: 719,
          name: "Gaming Chair",
          image: "/placeholder.svg?height=300&width=300&text=Chair",
          price: "$199.99",
        },
        {
          id: 720,
          name: "Gaming Mouse",
          image: "/placeholder.svg?height=300&width=300&text=Mouse",
          price: "$49.99",
        },
        {
          id: 721,
          name: "Gaming Keyboard",
          image: "/placeholder.svg?height=300&width=300&text=Keyboard",
          price: "$79.99",
        },
      ],
    },
    {
      category: "Virtual Reality",
      items: [
        {
          id: 722,
          name: "Meta Quest 3",
          image: "/placeholder.svg?height=300&width=300&text=Quest+3",
          price: "$499.99",
        },
        {
          id: 723,
          name: "PlayStation VR2",
          image: "/placeholder.svg?height=300&width=300&text=PSVR2",
          price: "$549.99",
        },
        {
          id: 724,
          name: "Valve Index",
          image: "/placeholder.svg?height=300&width=300&text=Index",
          price: "$999.99",
        },
        {
          id: 725,
          name: "VR Controllers",
          image: "/placeholder.svg?height=300&width=300&text=VR+Controllers",
          price: "$99.99",
        },
        {
          id: 726,
          name: "VR Cover",
          image: "/placeholder.svg?height=300&width=300&text=VR+Cover",
          price: "$29.99",
        },
        {
          id: 727,
          name: "VR Games Bundle",
          image: "/placeholder.svg?height=300&width=300&text=VR+Games",
          price: "$89.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Game Hub" products={products} />
}

