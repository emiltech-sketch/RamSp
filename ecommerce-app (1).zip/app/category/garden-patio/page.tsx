"use client"

import CategoryPage from "@/components/category-page"

export default function GardenPatioPage() {
  // Sample product data for Garden & Patio
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 1201,
          name: "Lawn Mower",
          image: "/placeholder.svg?height=300&width=300&text=Lawn+Mower",
          price: "$249.99",
        },
        {
          id: 1202,
          name: "Patio Furniture Set",
          image: "/placeholder.svg?height=300&width=300&text=Patio+Set",
          price: "$399.99",
        },
        {
          id: 1203,
          name: "Garden Tools",
          image: "/placeholder.svg?height=300&width=300&text=Garden+Tools",
          price: "$49.99",
        },
      ],
    },
    {
      category: "Outdoor Furniture",
      items: [
        {
          id: 1204,
          name: "Patio Furniture Set",
          image: "/placeholder.svg?height=300&width=300&text=Patio+Set",
          price: "$399.99",
        },
        {
          id: 1205,
          name: "Outdoor Dining Table",
          image: "/placeholder.svg?height=300&width=300&text=Dining+Table",
          price: "$199.99",
        },
        {
          id: 1206,
          name: "Adirondack Chair",
          image: "/placeholder.svg?height=300&width=300&text=Adirondack+Chair",
          price: "$79.99",
        },
        {
          id: 1207,
          name: "Patio Umbrella",
          image: "/placeholder.svg?height=300&width=300&text=Patio+Umbrella",
          price: "$89.99",
        },
        {
          id: 1208,
          name: "Outdoor Sofa",
          image: "/placeholder.svg?height=300&width=300&text=Outdoor+Sofa",
          price: "$299.99",
        },
        {
          id: 1209,
          name: "Hammock",
          image: "/placeholder.svg?height=300&width=300&text=Hammock",
          price: "$69.99",
        },
      ],
    },
    {
      category: "Gardening Tools",
      items: [
        {
          id: 1210,
          name: "Garden Tools Set",
          image: "/placeholder.svg?height=300&width=300&text=Garden+Tools",
          price: "$49.99",
        },
        {
          id: 1211,
          name: "Pruning Shears",
          image: "/placeholder.svg?height=300&width=300&text=Pruning+Shears",
          price: "$19.99",
        },
        {
          id: 1212,
          name: "Garden Hose",
          image: "/placeholder.svg?height=300&width=300&text=Garden+Hose",
          price: "$29.99",
        },
        {
          id: 1213,
          name: "Watering Can",
          image: "/placeholder.svg?height=300&width=300&text=Watering+Can",
          price: "$14.99",
        },
        {
          id: 1214,
          name: "Garden Gloves",
          image: "/placeholder.svg?height=300&width=300&text=Garden+Gloves",
          price: "$9.99",
        },
        {
          id: 1215,
          name: "Wheelbarrow",
          image: "/placeholder.svg?height=300&width=300&text=Wheelbarrow",
          price: "$79.99",
        },
      ],
    },
    {
      category: "Lawn Care",
      items: [
        {
          id: 1216,
          name: "Lawn Mower",
          image: "/placeholder.svg?height=300&width=300&text=Lawn+Mower",
          price: "$249.99",
        },
        {
          id: 1217,
          name: "Grass Seed",
          image: "/placeholder.svg?height=300&width=300&text=Grass+Seed",
          price: "$19.99",
        },
        {
          id: 1218,
          name: "Fertilizer",
          image: "/placeholder.svg?height=300&width=300&text=Fertilizer",
          price: "$24.99",
        },
        {
          id: 1219,
          name: "Weed Killer",
          image: "/placeholder.svg?height=300&width=300&text=Weed+Killer",
          price: "$14.99",
        },
        {
          id: 1220,
          name: "Sprinkler",
          image: "/placeholder.svg?height=300&width=300&text=Sprinkler",
          price: "$29.99",
        },
        {
          id: 1221,
          name: "Leaf Blower",
          image: "/placeholder.svg?height=300&width=300&text=Leaf+Blower",
          price: "$99.99",
        },
      ],
    },
    {
      category: "Outdoor Decor",
      items: [
        {
          id: 1222,
          name: "Outdoor Rug",
          image: "/placeholder.svg?height=300&width=300&text=Outdoor+Rug",
          price: "$49.99",
        },
        {
          id: 1223,
          name: "Garden Statue",
          image: "/placeholder.svg?height=300&width=300&text=Garden+Statue",
          price: "$39.99",
        },
        {
          id: 1224,
          name: "Outdoor Pillows",
          image: "/placeholder.svg?height=300&width=300&text=Outdoor+Pillows",
          price: "$24.99",
        },
        {
          id: 1225,
          name: "String Lights",
          image: "/placeholder.svg?height=300&width=300&text=String+Lights",
          price: "$29.99",
        },
        {
          id: 1226,
          name: "Bird Bath",
          image: "/placeholder.svg?height=300&width=300&text=Bird+Bath",
          price: "$59.99",
        },
        {
          id: 1227,
          name: "Wind Chimes",
          image: "/placeholder.svg?height=300&width=300&text=Wind+Chimes",
          price: "$19.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Garden & Patio" products={products} />
}

