"use client"

import CategoryPage from "@/components/category-page"

export default function HomeOfficePage() {
  // Sample product data for Home & Office
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 301,
          name: "Office Chair",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$149.99",
        },
        {
          id: 302,
          name: "Desk Lamp",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$39.99",
        },
        {
          id: 303,
          name: "Sofa",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$499.99",
        },
      ],
    },
    {
      category: "Furniture",
      items: [
        {
          id: 304,
          name: "Office Chair",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$149.99",
        },
        {
          id: 305,
          name: "Desk",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$199.99",
        },
        {
          id: 306,
          name: "Bookshelf",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$129.99",
        },
        {
          id: 307,
          name: "Sofa",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$499.99",
        },
        {
          id: 308,
          name: "Coffee Table",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$149.99",
        },
        {
          id: 309,
          name: "Dining Table",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$299.99",
        },
      ],
    },
    {
      category: "Office Supplies",
      items: [
        {
          id: 310,
          name: "Desk Organizer",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$24.99",
        },
        {
          id: 311,
          name: "Notebook",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$9.99",
        },
        {
          id: 312,
          name: "Pen Set",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$14.99",
        },
        {
          id: 313,
          name: "Stapler",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$12.99",
        },
        {
          id: 314,
          name: "File Cabinet",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$79.99",
        },
        {
          id: 315,
          name: "Desk Lamp",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$39.99",
        },
      ],
    },
    {
      category: "Home Decor",
      items: [
        {
          id: 316,
          name: "Wall Art",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$49.99",
        },
        {
          id: 317,
          name: "Throw Pillows",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$29.99",
        },
        {
          id: 318,
          name: "Area Rug",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$89.99",
        },
        {
          id: 319,
          name: "Curtains",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$59.99",
        },
        {
          id: 320,
          name: "Vase",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$34.99",
        },
        {
          id: 321,
          name: "Wall Clock",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$44.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Home & Office" products={products} />
}

