"use client"

import CategoryPage from "@/components/category-page"

export default function IndustrialTechPage() {
  // Sample product data for Industrial Tech
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 1401,
          name: "Power Drill",
          image: "/placeholder.svg?height=300&width=300&text=Power+Drill",
          price: "$89.99",
        },
        {
          id: 1402,
          name: "Safety Goggles",
          image: "/placeholder.svg?height=300&width=300&text=Safety+Goggles",
          price: "$14.99",
        },
        {
          id: 1403,
          name: "Industrial Printer",
          image: "/placeholder.svg?height=300&width=300&text=Industrial+Printer",
          price: "$499.99",
        },
      ],
    },
    {
      category: "Power Tools",
      items: [
        {
          id: 1404,
          name: "Power Drill",
          image: "/placeholder.svg?height=300&width=300&text=Power+Drill",
          price: "$89.99",
        },
        {
          id: 1405,
          name: "Circular Saw",
          image: "/placeholder.svg?height=300&width=300&text=Circular+Saw",
          price: "$129.99",
        },
        {
          id: 1406,
          name: "Impact Driver",
          image: "/placeholder.svg?height=300&width=300&text=Impact+Driver",
          price: "$79.99",
        },
        {
          id: 1407,
          name: "Angle Grinder",
          image: "/placeholder.svg?height=300&width=300&text=Angle+Grinder",
          price: "$69.99",
        },
        {
          id: 1408,
          name: "Jigsaw",
          image: "/placeholder.svg?height=300&width=300&text=Jigsaw",
          price: "$59.99",
        },
        {
          id: 1409,
          name: "Rotary Tool",
          image: "/placeholder.svg?height=300&width=300&text=Rotary+Tool",
          price: "$49.99",
        },
      ],
    },
    {
      category: "Safety Equipment",
      items: [
        {
          id: 1410,
          name: "Safety Goggles",
          image: "/placeholder.svg?height=300&width=300&text=Safety+Goggles",
          price: "$14.99",
        },
        {
          id: 1411,
          name: "Hard Hat",
          image: "/placeholder.svg?height=300&width=300&text=Hard+Hat",
          price: "$24.99",
        },
        {
          id: 1412,
          name: "Work Gloves",
          image: "/placeholder.svg?height=300&width=300&text=Work+Gloves",
          price: "$19.99",
        },
        {
          id: 1413,
          name: "Ear Protection",
          image: "/placeholder.svg?height=300&width=300&text=Ear+Protection",
          price: "$12.99",
        },
        {
          id: 1414,
          name: "Respirator",
          image: "/placeholder.svg?height=300&width=300&text=Respirator",
          price: "$29.99",
        },
        {
          id: 1415,
          name: "Safety Vest",
          image: "/placeholder.svg?height=300&width=300&text=Safety+Vest",
          price: "$16.99",
        },
      ],
    },
    {
      category: "Industrial Equipment",
      items: [
        {
          id: 1416,
          name: "Industrial Printer",
          image: "/placeholder.svg?height=300&width=300&text=Industrial+Printer",
          price: "$499.99",
        },
        {
          id: 1417,
          name: "Welding Machine",
          image: "/placeholder.svg?height=300&width=300&text=Welding+Machine",
          price: "$349.99",
        },
        {
          id: 1418,
          name: "Air Compressor",
          image: "/placeholder.svg?height=300&width=300&text=Air+Compressor",
          price: "$199.99",
        },
        {
          id: 1419,
          name: "Generator",
          image: "/placeholder.svg?height=300&width=300&text=Generator",
          price: "$599.99",
        },
        {
          id: 1420,
          name: "Pressure Washer",
          image: "/placeholder.svg?height=300&width=300&text=Pressure+Washer",
          price: "$249.99",
        },
        {
          id: 1421,
          name: "Industrial Fan",
          image: "/placeholder.svg?height=300&width=300&text=Industrial+Fan",
          price: "$179.99",
        },
      ],
    },
    {
      category: "Measurement & Testing",
      items: [
        {
          id: 1422,
          name: "Digital Multimeter",
          image: "/placeholder.svg?height=300&width=300&text=Multimeter",
          price: "$49.99",
        },
        {
          id: 1423,
          name: "Laser Level",
          image: "/placeholder.svg?height=300&width=300&text=Laser+Level",
          price: "$79.99",
        },
        {
          id: 1424,
          name: "Tape Measure",
          image: "/placeholder.svg?height=300&width=300&text=Tape+Measure",
          price: "$14.99",
        },
        {
          id: 1425,
          name: "Infrared Thermometer",
          image: "/placeholder.svg?height=300&width=300&text=IR+Thermometer",
          price: "$39.99",
        },
        {
          id: 1426,
          name: "Stud Finder",
          image: "/placeholder.svg?height=300&width=300&text=Stud+Finder",
          price: "$24.99",
        },
        {
          id: 1427,
          name: "Caliper",
          image: "/placeholder.svg?height=300&width=300&text=Caliper",
          price: "$29.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Industrial Tech" products={products} />
}

