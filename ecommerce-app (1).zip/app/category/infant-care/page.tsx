"use client"

import CategoryPage from "@/components/category-page"

export default function InfantCarePage() {
  // Sample product data for Infant Care
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 801,
          name: "Baby Formula",
          image: "/placeholder.svg?height=300&width=300&text=Formula",
          price: "$24.99",
        },
        {
          id: 802,
          name: "Diapers",
          image: "/placeholder.svg?height=300&width=300&text=Diapers",
          price: "$19.99",
        },
        {
          id: 803,
          name: "Baby Stroller",
          image: "/placeholder.svg?height=300&width=300&text=Stroller",
          price: "$149.99",
        },
      ],
    },
    {
      category: "Feeding",
      items: [
        {
          id: 804,
          name: "Baby Formula",
          image: "/placeholder.svg?height=300&width=300&text=Formula",
          price: "$24.99",
        },
        {
          id: 805,
          name: "Baby Bottles",
          image: "/placeholder.svg?height=300&width=300&text=Bottles",
          price: "$14.99",
        },
        {
          id: 806,
          name: "Sippy Cups",
          image: "/placeholder.svg?height=300&width=300&text=Sippy+Cups",
          price: "$9.99",
        },
        {
          id: 807,
          name: "High Chair",
          image: "/placeholder.svg?height=300&width=300&text=High+Chair",
          price: "$79.99",
        },
        {
          id: 808,
          name: "Baby Food",
          image: "/placeholder.svg?height=300&width=300&text=Baby+Food",
          price: "$2.99",
        },
        {
          id: 809,
          name: "Bibs",
          image: "/placeholder.svg?height=300&width=300&text=Bibs",
          price: "$7.99",
        },
      ],
    },
    {
      category: "Diapering",
      items: [
        {
          id: 810,
          name: "Diapers",
          image: "/placeholder.svg?height=300&width=300&text=Diapers",
          price: "$19.99",
        },
        {
          id: 811,
          name: "Baby Wipes",
          image: "/placeholder.svg?height=300&width=300&text=Wipes",
          price: "$4.99",
        },
        {
          id: 812,
          name: "Changing Pad",
          image: "/placeholder.svg?height=300&width=300&text=Changing+Pad",
          price: "$24.99",
        },
        {
          id: 813,
          name: "Diaper Bag",
          image: "/placeholder.svg?height=300&width=300&text=Diaper+Bag",
          price: "$39.99",
        },
        {
          id: 814,
          name: "Diaper Pail",
          image: "/placeholder.svg?height=300&width=300&text=Diaper+Pail",
          price: "$29.99",
        },
        {
          id: 815,
          name: "Diaper Rash Cream",
          image: "/placeholder.svg?height=300&width=300&text=Rash+Cream",
          price: "$8.99",
        },
      ],
    },
    {
      category: "Nursery",
      items: [
        {
          id: 816,
          name: "Crib",
          image: "/placeholder.svg?height=300&width=300&text=Crib",
          price: "$199.99",
        },
        {
          id: 817,
          name: "Crib Mattress",
          image: "/placeholder.svg?height=300&width=300&text=Mattress",
          price: "$89.99",
        },
        {
          id: 818,
          name: "Baby Monitor",
          image: "/placeholder.svg?height=300&width=300&text=Monitor",
          price: "$59.99",
        },
        {
          id: 819,
          name: "Changing Table",
          image: "/placeholder.svg?height=300&width=300&text=Changing+Table",
          price: "$129.99",
        },
        {
          id: 820,
          name: "Nursery Decor",
          image: "/placeholder.svg?height=300&width=300&text=Decor",
          price: "$49.99",
        },
        {
          id: 821,
          name: "Humidifier",
          image: "/placeholder.svg?height=300&width=300&text=Humidifier",
          price: "$39.99",
        },
      ],
    },
    {
      category: "Travel Gear",
      items: [
        {
          id: 822,
          name: "Baby Stroller",
          image: "/placeholder.svg?height=300&width=300&text=Stroller",
          price: "$149.99",
        },
        {
          id: 823,
          name: "Car Seat",
          image: "/placeholder.svg?height=300&width=300&text=Car+Seat",
          price: "$179.99",
        },
        {
          id: 824,
          name: "Baby Carrier",
          image: "/placeholder.svg?height=300&width=300&text=Carrier",
          price: "$69.99",
        },
        {
          id: 825,
          name: "Travel Crib",
          image: "/placeholder.svg?height=300&width=300&text=Travel+Crib",
          price: "$99.99",
        },
        {
          id: 826,
          name: "Stroller Accessories",
          image: "/placeholder.svg?height=300&width=300&text=Stroller+Acc",
          price: "$29.99",
        },
        {
          id: 827,
          name: "Car Seat Cover",
          image: "/placeholder.svg?height=300&width=300&text=Seat+Cover",
          price: "$19.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Infant Care" products={products} />
}

