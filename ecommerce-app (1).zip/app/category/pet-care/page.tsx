"use client"

import CategoryPage from "@/components/category-page"

export default function PetCarePage() {
  // Sample product data for Pet Care
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 901,
          name: "Dog Food",
          image: "/placeholder.svg?height=300&width=300&text=Dog+Food",
          price: "$29.99",
        },
        {
          id: 902,
          name: "Cat Litter",
          image: "/placeholder.svg?height=300&width=300&text=Cat+Litter",
          price: "$14.99",
        },
        {
          id: 903,
          name: "Pet Bed",
          image: "/placeholder.svg?height=300&width=300&text=Pet+Bed",
          price: "$39.99",
        },
      ],
    },
    {
      category: "Dog Supplies",
      items: [
        {
          id: 904,
          name: "Dog Food",
          image: "/placeholder.svg?height=300&width=300&text=Dog+Food",
          price: "$29.99",
        },
        {
          id: 905,
          name: "Dog Treats",
          image: "/placeholder.svg?height=300&width=300&text=Dog+Treats",
          price: "$9.99",
        },
        {
          id: 906,
          name: "Dog Toys",
          image: "/placeholder.svg?height=300&width=300&text=Dog+Toys",
          price: "$12.99",
        },
        {
          id: 907,
          name: "Dog Bed",
          image: "/placeholder.svg?height=300&width=300&text=Dog+Bed",
          price: "$39.99",
        },
        {
          id: 908,
          name: "Dog Collar",
          image: "/placeholder.svg?height=300&width=300&text=Dog+Collar",
          price: "$14.99",
        },
        {
          id: 909,
          name: "Dog Leash",
          image: "/placeholder.svg?height=300&width=300&text=Dog+Leash",
          price: "$19.99",
        },
      ],
    },
    {
      category: "Cat Supplies",
      items: [
        {
          id: 910,
          name: "Cat Food",
          image: "/placeholder.svg?height=300&width=300&text=Cat+Food",
          price: "$24.99",
        },
        {
          id: 911,
          name: "Cat Litter",
          image: "/placeholder.svg?height=300&width=300&text=Cat+Litter",
          price: "$14.99",
        },
        {
          id: 912,
          name: "Cat Toys",
          image: "/placeholder.svg?height=300&width=300&text=Cat+Toys",
          price: "$8.99",
        },
        {
          id: 913,
          name: "Cat Bed",
          image: "/placeholder.svg?height=300&width=300&text=Cat+Bed",
          price: "$34.99",
        },
        {
          id: 914,
          name: "Cat Scratching Post",
          image: "/placeholder.svg?height=300&width=300&text=Scratching+Post",
          price: "$29.99",
        },
        {
          id: 915,
          name: "Cat Carrier",
          image: "/placeholder.svg?height=300&width=300&text=Cat+Carrier",
          price: "$39.99",
        },
      ],
    },
    {
      category: "Fish & Aquarium",
      items: [
        {
          id: 916,
          name: "Fish Food",
          image: "/placeholder.svg?height=300&width=300&text=Fish+Food",
          price: "$6.99",
        },
        {
          id: 917,
          name: "Aquarium",
          image: "/placeholder.svg?height=300&width=300&text=Aquarium",
          price: "$79.99",
        },
        {
          id: 918,
          name: "Water Filter",
          image: "/placeholder.svg?height=300&width=300&text=Water+Filter",
          price: "$24.99",
        },
        {
          id: 919,
          name: "Aquarium Decor",
          image: "/placeholder.svg?height=300&width=300&text=Aquarium+Decor",
          price: "$19.99",
        },
        {
          id: 920,
          name: "Water Conditioner",
          image: "/placeholder.svg?height=300&width=300&text=Water+Conditioner",
          price: "$8.99",
        },
        {
          id: 921,
          name: "Fish Net",
          image: "/placeholder.svg?height=300&width=300&text=Fish+Net",
          price: "$4.99",
        },
      ],
    },
    {
      category: "Small Pets",
      items: [
        {
          id: 922,
          name: "Hamster Cage",
          image: "/placeholder.svg?height=300&width=300&text=Hamster+Cage",
          price: "$49.99",
        },
        {
          id: 923,
          name: "Small Pet Food",
          image: "/placeholder.svg?height=300&width=300&text=Small+Pet+Food",
          price: "$12.99",
        },
        {
          id: 924,
          name: "Exercise Wheel",
          image: "/placeholder.svg?height=300&width=300&text=Exercise+Wheel",
          price: "$14.99",
        },
        {
          id: 925,
          name: "Bedding",
          image: "/placeholder.svg?height=300&width=300&text=Bedding",
          price: "$9.99",
        },
        {
          id: 926,
          name: "Small Pet Toys",
          image: "/placeholder.svg?height=300&width=300&text=Small+Pet+Toys",
          price: "$7.99",
        },
        {
          id: 927,
          name: "Water Bottle",
          image: "/placeholder.svg?height=300&width=300&text=Water+Bottle",
          price: "$6.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Pet Care" products={products} />
}

