"use client"

import CategoryPage from "@/components/category-page"

export default function PhonesTabletsPage() {
  // Sample product data for Phones & Tablets
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 401,
          name: "Smartphone",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$299.99",
        },
        {
          id: 402,
          name: "Tablet",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$199.99",
        },
        {
          id: 403,
          name: "Phone Case",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$19.99",
        },
      ],
    },
    {
      category: "Smartphones",
      items: [
        {
          id: 404,
          name: "iPhone",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$799.99",
        },
        {
          id: 405,
          name: "Samsung Galaxy",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$699.99",
        },
        {
          id: 406,
          name: "Google Pixel",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$599.99",
        },
        {
          id: 407,
          name: "OnePlus",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$499.99",
        },
        {
          id: 408,
          name: "Xiaomi",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$399.99",
        },
        {
          id: 409,
          name: "Motorola",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$299.99",
        },
      ],
    },
    {
      category: "Tablets",
      items: [
        {
          id: 410,
          name: "iPad",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$499.99",
        },
        {
          id: 411,
          name: "Samsung Tab",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$399.99",
        },
        {
          id: 412,
          name: "Amazon Fire",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$149.99",
        },
        {
          id: 413,
          name: "Lenovo Tab",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$199.99",
        },
        {
          id: 414,
          name: "Huawei Tablet",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$249.99",
        },
        {
          id: 415,
          name: "Microsoft Surface",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
          price: "$599.99",
        },
      ],
    },
    {
      category: "Accessories",
      items: [
        {
          id: 416,
          name: "Phone Case",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$19.99",
        },
        {
          id: 417,
          name: "Screen Protector",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$9.99",
        },
        {
          id: 418,
          name: "Charger",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$24.99",
        },
        {
          id: 419,
          name: "Power Bank",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$39.99",
        },
        {
          id: 420,
          name: "Earbuds",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$59.99",
        },
        {
          id: 421,
          name: "Tablet Stand",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.15.08-pMG7hwWiIlLbFdv0hIKZH3a93QKU9N.png",
          price: "$14.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Phones & Tablets" products={products} />
}

