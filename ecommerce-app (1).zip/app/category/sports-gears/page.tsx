"use client"

import CategoryPage from "@/components/category-page"

export default function SportsGearsPage() {
  // Sample product data for Sports Gears
  const products = [
    {
      category: "All Products",
      items: [
        {
          id: 1001,
          name: "Basketball",
          image: "/placeholder.svg?height=300&width=300&text=Basketball",
          price: "$29.99",
        },
        {
          id: 1002,
          name: "Running Shoes",
          image: "/placeholder.svg?height=300&width=300&text=Running+Shoes",
          price: "$89.99",
        },
        {
          id: 1003,
          name: "Yoga Mat",
          image: "/placeholder.svg?height=300&width=300&text=Yoga+Mat",
          price: "$24.99",
        },
      ],
    },
    {
      category: "Team Sports",
      items: [
        {
          id: 1004,
          name: "Basketball",
          image: "/placeholder.svg?height=300&width=300&text=Basketball",
          price: "$29.99",
        },
        {
          id: 1005,
          name: "Football",
          image: "/placeholder.svg?height=300&width=300&text=Football",
          price: "$24.99",
        },
        {
          id: 1006,
          name: "Soccer Ball",
          image: "/placeholder.svg?height=300&width=300&text=Soccer+Ball",
          price: "$19.99",
        },
        {
          id: 1007,
          name: "Baseball Bat",
          image: "/placeholder.svg?height=300&width=300&text=Baseball+Bat",
          price: "$49.99",
        },
        {
          id: 1008,
          name: "Volleyball",
          image: "/placeholder.svg?height=300&width=300&text=Volleyball",
          price: "$22.99",
        },
        {
          id: 1009,
          name: "Tennis Racket",
          image: "/placeholder.svg?height=300&width=300&text=Tennis+Racket",
          price: "$59.99",
        },
      ],
    },
    {
      category: "Fitness",
      items: [
        {
          id: 1010,
          name: "Dumbbells",
          image: "/placeholder.svg?height=300&width=300&text=Dumbbells",
          price: "$39.99",
        },
        {
          id: 1011,
          name: "Yoga Mat",
          image: "/placeholder.svg?height=300&width=300&text=Yoga+Mat",
          price: "$24.99",
        },
        {
          id: 1012,
          name: "Resistance Bands",
          image: "/placeholder.svg?height=300&width=300&text=Resistance+Bands",
          price: "$14.99",
        },
        {
          id: 1013,
          name: "Jump Rope",
          image: "/placeholder.svg?height=300&width=300&text=Jump+Rope",
          price: "$9.99",
        },
        {
          id: 1014,
          name: "Exercise Bike",
          image: "/placeholder.svg?height=300&width=300&text=Exercise+Bike",
          price: "$299.99",
        },
        {
          id: 1015,
          name: "Treadmill",
          image: "/placeholder.svg?height=300&width=300&text=Treadmill",
          price: "$499.99",
        },
      ],
    },
    {
      category: "Outdoor Recreation",
      items: [
        {
          id: 1016,
          name: "Camping Tent",
          image: "/placeholder.svg?height=300&width=300&text=Camping+Tent",
          price: "$129.99",
        },
        {
          id: 1017,
          name: "Hiking Backpack",
          image: "/placeholder.svg?height=300&width=300&text=Hiking+Backpack",
          price: "$79.99",
        },
        {
          id: 1018,
          name: "Fishing Rod",
          image: "/placeholder.svg?height=300&width=300&text=Fishing+Rod",
          price: "$49.99",
        },
        {
          id: 1019,
          name: "Kayak",
          image: "/placeholder.svg?height=300&width=300&text=Kayak",
          price: "$349.99",
        },
        {
          id: 1020,
          name: "Bicycle",
          image: "/placeholder.svg?height=300&width=300&text=Bicycle",
          price: "$299.99",
        },
        {
          id: 1021,
          name: "Skateboard",
          image: "/placeholder.svg?height=300&width=300&text=Skateboard",
          price: "$59.99",
        },
      ],
    },
    {
      category: "Athletic Apparel",
      items: [
        {
          id: 1022,
          name: "Running Shoes",
          image: "/placeholder.svg?height=300&width=300&text=Running+Shoes",
          price: "$89.99",
        },
        {
          id: 1023,
          name: "Athletic Shorts",
          image: "/placeholder.svg?height=300&width=300&text=Athletic+Shorts",
          price: "$24.99",
        },
        {
          id: 1024,
          name: "Sports Bra",
          image: "/placeholder.svg?height=300&width=300&text=Sports+Bra",
          price: "$29.99",
        },
        {
          id: 1025,
          name: "Compression Shirt",
          image: "/placeholder.svg?height=300&width=300&text=Compression+Shirt",
          price: "$34.99",
        },
        {
          id: 1026,
          name: "Athletic Socks",
          image: "/placeholder.svg?height=300&width=300&text=Athletic+Socks",
          price: "$12.99",
        },
        {
          id: 1027,
          name: "Sweatpants",
          image: "/placeholder.svg?height=300&width=300&text=Sweatpants",
          price: "$39.99",
        },
      ],
    },
  ]

  return <CategoryPage categoryName="Sports Gears" products={products} />
}

