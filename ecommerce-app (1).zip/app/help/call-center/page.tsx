"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Phone, Mail, MessageCircle, Clock, X } from "lucide-react"
import { useRouter } from "next/navigation"
import MobileNavigation from "@/components/mobile-navigation"
import { Button } from "@/components/ui/button"

export default function CallCenterPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("help")
  const [showCallModal, setShowCallModal] = useState(false)
  const [showEmailModal, setShowEmailModal] = useState(false)
  const [showChatModal, setShowChatModal] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    if (tab === "home") {
      router.push("/")
    } else if (tab === "categories") {
      router.push("/category/all")
    } else if (tab === "cart") {
      router.push("/cart")
    } else if (tab === "account") {
      router.push("/account")
    }
  }

  const handleCall = () => {
    // Use the tel: protocol to initiate a call
    window.location.href = "tel:+18001234567"
  }

  const handleEmail = () => {
    // Use the mailto: protocol to open email client
    window.location.href = "mailto:support@ramsphere.com"
  }

  const handleChat = () => {
    setShowChatModal(true)
  }

  const handleSubmitEmail = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate sending email
    setTimeout(() => {
      setIsSubmitting(false)
      setSubmitted(true)

      // Reset form
      setTimeout(() => {
        setShowEmailModal(false)
        setSubmitted(false)
      }, 2000)
    }, 1500)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-[#40E0D0] shadow-sm">
        <div className="px-4 py-3">
          <div className="flex items-center">
            <Link href="/help" className="flex items-center">
              <ArrowLeft className="h-5 w-5 text-white mr-2" />
              <span className="text-white font-bold text-lg">Call Center</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="flex-1 p-4 pb-16">
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
          <h2 className="font-medium mb-4">Contact Us</h2>

          <div className="space-y-4">
            <div className="flex items-start">
              <div className="bg-[#DEA818] rounded-full p-2 mr-3 text-white">
                <Phone className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-medium">Customer Support</h3>
                <p className="text-sm text-gray-500 mb-2">Call us for immediate assistance</p>
                <Button className="bg-[#DEA818] hover:bg-[#c99616]" size="sm" onClick={handleCall}>
                  +1 (800) 123-4567
                </Button>
              </div>
            </div>

            <div className="flex items-start">
              <div className="bg-[#DEA818] rounded-full p-2 mr-3 text-white">
                <Mail className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-medium">Email Support</h3>
                <p className="text-sm text-gray-500 mb-2">Send us an email</p>
                <Button variant="outline" size="sm" onClick={handleEmail}>
                  support@ramsphere.com
                </Button>
              </div>
            </div>

            <div className="flex items-start">
              <div className="bg-[#DEA818] rounded-full p-2 mr-3 text-white">
                <MessageCircle className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-medium">Live Chat</h3>
                <p className="text-sm text-gray-500 mb-2">Chat with our support team</p>
                <Button className="bg-[#DEA818] hover:bg-[#c99616]" size="sm" onClick={handleChat}>
                  Start Chat
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4">
          <div className="flex items-start">
            <div className="bg-[#DEA818] rounded-full p-2 mr-3 text-white">
              <Clock className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-medium">Business Hours</h3>
              <div className="text-sm text-gray-500 mt-2 space-y-1">
                <p>Monday - Friday: 8:00 AM - 8:00 PM</p>
                <p>Saturday: 9:00 AM - 6:00 PM</p>
                <p>Sunday: 10:00 AM - 4:00 PM</p>
                <p className="text-xs mt-2">(All times in Eastern Time)</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Modal */}
      {showChatModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md overflow-hidden">
            <div className="bg-[#40E0D0] p-4 flex items-center justify-between">
              <h2 className="text-white font-bold">Chat with Support</h2>
              <button className="text-white" onClick={() => setShowChatModal(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="h-80 p-4 overflow-y-auto border-b">
              <div className="flex flex-col space-y-3">
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%] self-start">
                  <p className="text-sm">Hello! How can I help you today?</p>
                  <p className="text-xs text-gray-500 mt-1">Support • 10:30 AM</p>
                </div>

                <div className="bg-blue-100 rounded-lg p-3 max-w-[80%] self-end">
                  <p className="text-sm">I have a question about my recent order.</p>
                  <p className="text-xs text-gray-500 mt-1">You • 10:31 AM</p>
                </div>

                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%] self-start">
                  <p className="text-sm">I'd be happy to help with that. Could you please provide your order number?</p>
                  <p className="text-xs text-gray-500 mt-1">Support • 10:32 AM</p>
                </div>
              </div>
            </div>

            <div className="p-4 flex">
              <input
                type="text"
                placeholder="Type your message..."
                className="flex-1 border border-gray-300 rounded-l-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[#40E0D0]"
                id="chatMessage"
              />
              <button
                className="bg-[#DEA818] text-white px-4 py-2 rounded-r-lg"
                onClick={() => {
                  const messageInput = document.getElementById("chatMessage") as HTMLInputElement
                  if (messageInput && messageInput.value.trim()) {
                    // Add message to chat
                    const chatContainer = document.querySelector(".h-80")
                    if (chatContainer) {
                      const messageDiv = document.createElement("div")
                      messageDiv.className = "bg-blue-100 rounded-lg p-3 max-w-[80%] self-end mt-3"
                      messageDiv.innerHTML = `
                        <p class="text-sm">${messageInput.value}</p>
                        <p class="text-xs text-gray-500 mt-1">You • ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
                      `
                      chatContainer.appendChild(messageDiv)
                      chatContainer.scrollTop = chatContainer.scrollHeight

                      // Clear input
                      messageInput.value = ""

                      // Simulate response after a delay
                      setTimeout(() => {
                        const responseDiv = document.createElement("div")
                        responseDiv.className = "bg-gray-100 rounded-lg p-3 max-w-[80%] self-start mt-3"
                        responseDiv.innerHTML = `
                          <p class="text-sm">Thank you for providing that information. Our team will look into this right away.</p>
                          <p class="text-xs text-gray-500 mt-1">Support • ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
                        `
                        chatContainer.appendChild(responseDiv)
                        chatContainer.scrollTop = chatContainer.scrollHeight
                      }, 1000)
                    }
                  }
                }}
              >
                Send
              </button>
            </div>
          </div>
        </div>
      )}

      <MobileNavigation activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  )
}

