"use client"

import { useState, useEffect } from "react"
import SplashScreen from "@/components/splash-screen"
import WelcomeScreen from "@/components/welcome-screen"
import SignInScreen from "@/components/sign-in-screen"
import HomePage from "@/components/home-page"

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<"splash" | "welcome" | "signin" | "home">("splash")
  const [username, setUsername] = useState("Guest")

  useEffect(() => {
    // Check if user has visited before and is logged in
    const hasVisitedBefore = localStorage.getItem("hasVisitedBefore")
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    const savedUsername = localStorage.getItem("username")

    // Only run this effect once when the component mounts
    if (savedUsername) {
      setUsername(savedUsername)
    }
  }, [])

  const handleSplashComplete = () => {
    const hasVisitedBefore = localStorage.getItem("hasVisitedBefore")
    const isLoggedIn = localStorage.getItem("isLoggedIn")

    if (!hasVisitedBefore) {
      // First time visitor
      setCurrentScreen("welcome")
      localStorage.setItem("hasVisitedBefore", "true")
    } else if (!isLoggedIn) {
      // Returning visitor but not logged in
      setCurrentScreen("signin")
    } else {
      // Returning visitor and logged in
      setCurrentScreen("home")
    }
  }

  const handleWelcomeComplete = () => {
    setCurrentScreen("signin")
  }

  const handleSignIn = (user: string) => {
    setUsername(user)
    localStorage.setItem("isLoggedIn", "true")
    localStorage.setItem("username", user)
    setCurrentScreen("home")
  }

  const handleSkipSignIn = () => {
    setCurrentScreen("home")
  }

  switch (currentScreen) {
    case "splash":
      return <SplashScreen onComplete={handleSplashComplete} />
    case "welcome":
      return <WelcomeScreen onGetStarted={handleWelcomeComplete} />
    case "signin":
      return <SignInScreen onSignIn={handleSignIn} onSkip={handleSkipSignIn} />
    case "home":
      return <HomePage username={username} />
    default:
      return <HomePage username={username} />
  }
}

