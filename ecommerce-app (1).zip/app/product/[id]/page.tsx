"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, ShoppingCart, Heart, Star, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-provider"
import MobileNavigation from "@/components/mobile-navigation"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample product data
const products = [
  {
    id: 1,
    name: "Washing Machine",
    price: 499.99,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%2014.14.53-firaaQh1drI3JIje93XnpN14z4gsIe.png",
    description: "High-efficiency washing machine with multiple wash cycles and energy-saving features.",
    rating: 4.5,
    reviews: 120,
    specifications: [
      { name: "Capacity", value: "8kg" },
      { name: "Energy Rating", value: "A+++" },
      { name: "Spin Speed", value: "1400 RPM" },
      { name: "Dimensions", value: "60 x 85 x 60 cm" },
      { name: "Color", value: "White" },
      { name: "Warranty", value: "2 Years" },
    ],
  },
  {
    id: 2,
    name: "Smartphone",
    price: 299.99,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
    description: "Latest smartphone with high-resolution camera and long-lasting battery.",
    rating: 4.2,
    reviews: 85,
    specifications: [
      { name: "Screen Size", value: "6.5 inches" },
      { name: "RAM", value: "8GB" },
      { name: "Storage", value: "128GB" },
      { name: "Camera", value: "48MP + 12MP + 8MP" },
      { name: "Battery", value: "4500mAh" },
      { name: "OS", value: "Android 12" },
    ],
  },
  {
    id: 3,
    name: "Laptop",
    price: 799.99,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
    description: "Powerful laptop for work and entertainment with high-performance processor.",
    rating: 4.7,
    reviews: 210,
    specifications: [
      { name: "Processor", value: "Intel Core i7" },
      { name: "RAM", value: "16GB" },
      { name: "Storage", value: "512GB SSD" },
      { name: "Display", value: "15.6 inches, Full HD" },
      { name: "Graphics", value: "NVIDIA GeForce RTX 3050" },
      { name: "Battery Life", value: "Up to 8 hours" },
    ],
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { addToCart } = useCart()
  const [activeTab, setActiveTab] = useState("home")
  const [expandedSpecs, setExpandedSpecs] = useState(false)

  const productId = Number.parseInt(params.id)
  const product = products.find((p) => p.id === productId)

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    if (tab === "home") {
      router.push("/")
    } else if (tab === "categories") {
      router.push("/category/all")
    } else if (tab === "cart") {
      router.push("/cart")
    } else if (tab === "account") {
      router.push("/account")
    } else if (tab === "help") {
      router.push("/help")
    }
  }

  if (!product) {
    return (
      <div className="flex flex-col min-h-screen bg-gray-50">
        <header className="bg-[#40E0D0] shadow-sm">
          <div className="px-4 py-3">
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <ArrowLeft className="h-5 w-5 text-white mr-2" />
                <span className="text-white font-bold text-lg">Product Details</span>
              </Link>
            </div>
          </div>
        </header>

        <div className="flex-1 px-4 py-8 flex flex-col items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-4">Product not found</h2>
            <Link href="/">
              <Button className="bg-[#DEA818] hover:bg-[#c99616]">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Products
              </Button>
            </Link>
          </div>
        </div>

        <MobileNavigation activeTab={activeTab} onTabChange={handleTabChange} />
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-[#40E0D0] shadow-sm">
        <div className="px-4 py-3">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <ArrowLeft className="h-5 w-5 text-white mr-2" />
              <span className="text-white font-bold text-lg">Product Details</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="flex-1 pb-20">
        {/* Product Image */}
        <div className="bg-white p-4 flex justify-center">
          <div className="relative h-64 w-64">
            <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-contain" />
          </div>
        </div>

        {/* Product Info */}
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h1 className="text-xl font-bold">{product.name}</h1>
            <button className="text-gray-400">
              <Heart className="h-5 w-5" />
            </button>
          </div>

          <div className="flex items-center mb-3">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-4 w-4" fill={i < Math.floor(product.rating) ? "currentColor" : "none"} />
              ))}
            </div>
            <span className="text-sm text-gray-500 ml-2">({product.reviews} reviews)</span>
          </div>

          <p className="text-2xl font-bold text-[#DEA818] mb-4">${product.price.toFixed(2)}</p>

          <p className="text-sm text-gray-600 mb-4">{product.description}</p>

          <Tabs defaultValue="details" className="mb-4">
            <TabsList className="w-full">
              <TabsTrigger value="details" className="flex-1">
                Details
              </TabsTrigger>
              <TabsTrigger value="specifications" className="flex-1">
                Specifications
              </TabsTrigger>
              <TabsTrigger value="reviews" className="flex-1">
                Reviews
              </TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="mt-4">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h3 className="font-semibold mb-2">Product Details</h3>
                <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                  <li>High-quality materials</li>
                  <li>Durable construction</li>
                  <li>30-day money-back guarantee</li>
                  <li>Free shipping on orders over $50</li>
                  <li>2-year warranty included</li>
                </ul>
              </div>
            </TabsContent>
            <TabsContent value="specifications" className="mt-4">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold">Specifications</h3>
                  <button onClick={() => setExpandedSpecs(!expandedSpecs)}>
                    {expandedSpecs ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </button>
                </div>
                <div className="text-sm">
                  {(expandedSpecs ? product.specifications : product.specifications.slice(0, 3)).map((spec, index) => (
                    <div key={index} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">{spec.name}</span>
                      <span className="font-medium">{spec.value}</span>
                    </div>
                  ))}
                  {!expandedSpecs && product.specifications.length > 3 && (
                    <button
                      className="text-[#DEA818] font-medium mt-2 text-center w-full"
                      onClick={() => setExpandedSpecs(true)}
                    >
                      Show More
                    </button>
                  )}
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="mt-4">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h3 className="font-semibold mb-2">Customer Reviews</h3>
                <div className="flex items-center mb-4">
                  <div className="text-3xl font-bold mr-3">{product.rating.toFixed(1)}</div>
                  <div>
                    <div className="flex text-yellow-400 mb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className="h-4 w-4"
                          fill={i < Math.floor(product.rating) ? "currentColor" : "none"}
                        />
                      ))}
                    </div>
                    <div className="text-sm text-gray-500">Based on {product.reviews} reviews</div>
                  </div>
                </div>
                <Button className="w-full">Write a Review</Button>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex gap-3">
            <Button className="flex-1 bg-[#DEA818] hover:bg-[#c99616]" onClick={() => addToCart(product)}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </Button>
            <Link href="/cart" className="flex-1">
              <Button variant="outline" className="w-full">
                Buy Now
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <MobileNavigation activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  )
}

