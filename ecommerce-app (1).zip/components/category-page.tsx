"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { useRouter } from "next/navigation"

interface Product {
  id: number
  name: string
  image: string
  price: string
}

interface ProductCategory {
  category: string
  items: Product[]
}

interface CategoryPageProps {
  categoryName: string
  products: ProductCategory[]
  categories?: string[]
  onCategoryClick?: (category: string) => void
  onSeeAllClick?: (category: string) => void
}

export default function CategoryPage({
  categoryName,
  products,
  categories = [],
  onCategoryClick,
  onSeeAllClick,
}: CategoryPageProps) {
  const router = useRouter()
  const [activeCategory, setActiveCategory] = useState("All Products")

  // List of all available categories for the sidebar
  const allCategories = [
    { name: "All", path: "/category/all" },
    { name: "Electronics", path: "/category/electronics" },
    { name: "FoodMart", path: "/category/foodmart" },
    { name: "Beauty Care", path: "/category/beautycare" },
    { name: "Home & Office", path: "/category/home-office" },
    { name: "Phones & Tablets", path: "/category/phones-tablets" },
    { name: "Computers", path: "/category/computers-peripherals" },
    { name: "Fashion", path: "/category/fashion" },
    { name: "Entertainment", path: "/category/entertainment" },
    { name: "Game Hub", path: "/category/game-hub" },
    { name: "Infant Care", path: "/category/infant-care" },
    { name: "Pet Care", path: "/category/pet-care" },
    { name: "Sports Gears", path: "/category/sports-gears" },
    { name: "Automobile", path: "/category/automobile" },
    { name: "Garden & Patio", path: "/category/garden-patio" },
    { name: "Industrial Tech", path: "/category/industrial-tech" },
  ]

  const filteredProducts =
    activeCategory === "All Products"
      ? products.flatMap((category) => category.items)
      : products.find((category) => category.category === activeCategory)?.items || []

  const handleCategorySelect = (category: string) => {
    setActiveCategory(category)
    if (onCategoryClick) {
      onCategoryClick(category)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#40E0D0] p-4 sticky top-0 z-10">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-3">
            <ChevronLeft className="h-6 w-6 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white">{categoryName}</h1>
        </div>
      </header>

      <div className="flex">
        {/* Category Sidebar */}
        <div className="w-1/3 bg-white p-2 overflow-y-auto max-h-[calc(100vh-64px)] sticky top-16">
          <h2 className="font-semibold mb-2 px-2">Categories</h2>
          <ul>
            {allCategories.map((category, index) => (
              <li key={index}>
                <Link
                  href={category.path}
                  className={`block px-2 py-2 rounded-md text-sm ${
                    category.name === categoryName ? "bg-[#E6F7F5] text-[#40E0D0] font-medium" : ""
                  }`}
                >
                  {category.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Products */}
        <div className="w-2/3 p-4">
          {/* Category Tabs */}
          <div className="mb-4 overflow-x-auto">
            <div className="flex space-x-2 whitespace-nowrap">
              {products.map((category, index) => (
                <button
                  key={index}
                  className={`px-3 py-1 rounded-full text-sm ${
                    activeCategory === category.category ? "bg-[#40E0D0] text-white" : "bg-gray-100 text-gray-700"
                  }`}
                  onClick={() => handleCategorySelect(category.category)}
                >
                  {category.category}
                </button>
              ))}
            </div>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-2 gap-3">
            {filteredProducts.map((product, index) => (
              <Link
                href={`/product/${product.id}`}
                key={index}
                className="bg-white rounded-lg shadow-sm overflow-hidden"
              >
                <div className="relative h-32 w-full">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-contain p-2"
                  />
                </div>
                <div className="p-2">
                  <h3 className="font-medium text-sm">{product.name}</h3>
                  <p className="text-[#DEA818] font-bold text-sm">{product.price}</p>
                </div>
              </Link>
            ))}
          </div>

          {/* See All Button */}
          {activeCategory !== "All Products" && filteredProducts.length > 6 && (
            <div className="mt-4 text-center">
              <button
                className="px-4 py-2 bg-[#40E0D0] text-white rounded-md"
                onClick={() => onSeeAllClick && onSeeAllClick(activeCategory)}
              >
                See All
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

