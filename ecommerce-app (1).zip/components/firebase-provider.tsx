"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { getFirebaseAuth, getFirebaseFirestore, getFirebaseStorage } from "@/lib/firebase"
import type { User } from "firebase/auth"

// Create context
interface FirebaseContextType {
  auth: any
  db: any
  storage: any
  user: User | null
  loading: boolean
}

const FirebaseContext = createContext<FirebaseContextType>({
  auth: null,
  db: null,
  storage: null,
  user: null,
  loading: true,
})

// Provider component
export function FirebaseProvider({ children }: { children: ReactNode }) {
  const [auth, setAuth] = useState<any>(null)
  const [db, setDb] = useState<any>(null)
  const [storage, setStorage] = useState<any>(null)
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Initialize Firebase services
    const authInstance = getFirebaseAuth()
    const dbInstance = getFirebaseFirestore()
    const storageInstance = getFirebaseStorage()

    setAuth(authInstance)
    setDb(dbInstance)
    setStorage(storageInstance)

    // Set up auth state listener
    if (authInstance) {
      const unsubscribe = authInstance.onAuthStateChanged((user: User | null) => {
        setUser(user)
        setLoading(false)
      })

      // Cleanup subscription
      return () => unsubscribe()
    } else {
      setLoading(false)
    }
  }, [])

  return <FirebaseContext.Provider value={{ auth, db, storage, user, loading }}>{children}</FirebaseContext.Provider>
}

// Custom hook to use the Firebase context
export const useFirebase = () => useContext(FirebaseContext)

