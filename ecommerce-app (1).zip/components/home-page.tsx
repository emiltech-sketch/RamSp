"use client"

import type React from "react"
import { useState, useEffect, createContext, useContext } from "react"

import Image from "next/image"
import Link from "next/link"
import { Search, Mic, Camera, ChevronRight, MessageSquare } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useRouter } from "next/navigation"
import MobileNavigation from "./mobile-navigation"
import CategoryNavigation from "./category-navigation"
import VoiceSearch from "./voice-search"
import CameraSearch from "./camera-search"
import AIChatSupport from "./ai-chat-support"
import CurrencySettings from "./currency-settings"

// Create currency context
interface CurrencyOption {
  code: string
  symbol: string
  name: string
}

const CurrencyContext = createContext<{
  currency: CurrencyOption
  setCurrency: (currency: CurrencyOption) => void
}>({
  currency: { code: "USD", symbol: "$", name: "US Dollar" },
  setCurrency: () => {},
})

export const useCurrency = () => useContext(CurrencyContext)

interface HomePageProps {
  username?: string
}

export default function HomePage({ username = "Guest" }: HomePageProps) {
  // Currency state
  const [currency, setCurrency] = useState<CurrencyOption>({ code: "USD", symbol: "$", name: "US Dollar" })

  // Sample banner images
  const banners = [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/laptop.png-4Rvp1LU3tGm6TnCaZU4Qf72zb0HsT6.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smartp.png-8EFQyWIKOLZXG34zTcCQhGK9tPtB4r.jpeg",
  ]

  // Product banners
  const productBanners = [
    {
      id: 1,
      title: "New Arrivals",
      description: "Check out our latest products",
      image: "/placeholder.svg?height=200&width=400&text=New+Arrivals",
      link: "/products/new-arrivals",
      color: "bg-blue-500",
    },
    {
      id: 2,
      title: "Summer Sale",
      description: "Up to 50% off on selected items",
      image: "/placeholder.svg?height=200&width=400&text=Summer+Sale",
      link: "/products/sale",
      color: "bg-orange-500",
    },
    {
      id: 3,
      title: "Electronics",
      description: "Latest gadgets and devices",
      image: "/placeholder.svg?height=200&width=400&text=Electronics",
      link: "/category/electronics",
      color: "bg-purple-500",
    },
  ]

  const [currentBanner, setCurrentBanner] = useState(0)
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [banners.length])

  const router = useRouter()
  const [activeTab, setActiveTab] = useState("home")
  const [showVoiceSearch, setShowVoiceSearch] = useState(false)
  const [showCameraSearch, setShowCameraSearch] = useState(false)
  const [showChatSupport, setShowChatSupport] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    if (tab === "categories") {
      router.push("/category/all")
    } else if (tab === "cart") {
      router.push("/cart")
    } else if (tab === "account") {
      router.push("/account")
    } else if (tab === "help") {
      router.push("/help")
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
    }
  }

  // Featured products data
  const featuredProducts = [
    {
      id: 1,
      name: "Wireless Earbuds",
      image: "/placeholder.svg?height=200&width=200&text=Earbuds",
      price: 49.99,
      discount: "20% OFF",
    },
    {
      id: 2,
      name: "Smart Watch",
      image: "/placeholder.svg?height=200&width=200&text=Smart+Watch",
      price: 129.99,
      discount: "15% OFF",
    },
    {
      id: 3,
      name: "Bluetooth Speaker",
      image: "/placeholder.svg?height=200&width=200&text=Speaker",
      price: 79.99,
      discount: "10% OFF",
    },
    {
      id: 4,
      name: "Smartphone",
      image: "/placeholder.svg?height=200&width=200&text=Smartphone",
      price: 499.99,
      discount: "5% OFF",
    },
    {
      id: 5,
      name: "Laptop",
      image: "/placeholder.svg?height=200&width=200&text=Laptop",
      price: 899.99,
      discount: "12% OFF",
    },
    {
      id: 6,
      name: "Tablet",
      image: "/placeholder.svg?height=200&width=200&text=Tablet",
      price: 349.99,
      discount: "8% OFF",
    },
  ]

  // Categories data
  const categories = [
    {
      name: "Electronics",
      image: "/placeholder.svg?height=100&width=100&text=Electronics",
      path: "/category/electronics",
    },
    {
      name: "Fashion",
      image: "/placeholder.svg?height=100&width=100&text=Fashion",
      path: "/category/fashion",
    },
    {
      name: "Home & Office",
      image: "/placeholder.svg?height=100&width=100&text=Home",
      path: "/category/home-office",
    },
    {
      name: "Beauty Care",
      image: "/placeholder.svg?height=100&width=100&text=Beauty",
      path: "/category/beautycare",
    },
    {
      name: "FoodMart",
      image: "/placeholder.svg?height=100&width=100&text=Food",
      path: "/category/foodmart",
    },
    {
      name: "Sports & Gears",
      image: "/placeholder.svg?height=100&width=100&text=Sports",
      path: "/category/sports-gears",
    },
    {
      name: "Phones & Tablets",
      image: "/placeholder.svg?height=100&width=100&text=Phones",
      path: "/category/phones-tablets",
    },
    {
      name: "Computers",
      image: "/placeholder.svg?height=100&width=100&text=Computers",
      path: "/category/computers-peripherals",
    },
  ]

  // Flash deals data
  const flashDeals = [
    {
      id: 101,
      name: "Wireless Headphones",
      image: "/placeholder.svg?height=200&width=200&text=Headphones",
      originalPrice: 99.99,
      discountedPrice: 59.99,
      discount: "40% OFF",
      timeLeft: "2h 15m",
    },
    {
      id: 102,
      name: "Coffee Maker",
      image: "/placeholder.svg?height=200&width=200&text=Coffee+Maker",
      originalPrice: 149.99,
      discountedPrice: 89.99,
      discount: "40% OFF",
      timeLeft: "3h 45m",
    },
    {
      id: 103,
      name: "Fitness Tracker",
      image: "/placeholder.svg?height=200&width=200&text=Fitness+Tracker",
      originalPrice: 79.99,
      discountedPrice: 49.99,
      discount: "38% OFF",
      timeLeft: "1h 30m",
    },
    {
      id: 104,
      name: "Smart TV",
      image: "/placeholder.svg?height=200&width=200&text=Smart+TV",
      originalPrice: 599.99,
      discountedPrice: 399.99,
      discount: "33% OFF",
      timeLeft: "4h 20m",
    },
    {
      id: 105,
      name: "Gaming Console",
      image: "/placeholder.svg?height=200&width=200&text=Gaming+Console",
      originalPrice: 499.99,
      discountedPrice: 349.99,
      discount: "30% OFF",
      timeLeft: "5h 10m",
    },
    {
      id: 106,
      name: "Digital Camera",
      image: "/placeholder.svg?height=200&width=200&text=Digital+Camera",
      originalPrice: 399.99,
      discountedPrice: 249.99,
      discount: "38% OFF",
      timeLeft: "2h 45m",
    },
  ]

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency }}>
      <div className="min-h-screen bg-gray-50 pb-16">
        <header className="bg-[#40E0D0] p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <div className="relative h-8 w-8 mr-2">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/r-wjDSju0zJt1TdulWpb6FPeZ235IGXT.png"
                  alt="RamSphere Logo"
                  fill
                  className="object-contain"
                />
              </div>
              <span className="text-white font-bold text-lg">RamSphere</span>
            </div>
            <CurrencySettings currentCurrency={currency} onSelect={setCurrency} />
          </div>

          <form onSubmit={handleSearch} className="relative">
            <Input
              type="text"
              placeholder="Search products..."
              className="pl-10 pr-20 py-2 w-full rounded-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex space-x-2">
              <button type="button" onClick={() => setShowVoiceSearch(true)}>
                <Mic className="h-5 w-5 text-gray-400" />
              </button>
              <button type="button" onClick={() => setShowCameraSearch(true)}>
                <Camera className="h-5 w-5 text-gray-400" />
              </button>
            </div>
          </form>
        </header>

        <CategoryNavigation />

        <main className="p-4">
          {/* Banner Carousel */}
          <div className="relative rounded-xl overflow-hidden mb-6 h-40">
            <Image src={banners[currentBanner] || "/placeholder.svg"} alt="Banner" fill className="object-cover" />
            <div className="absolute bottom-2 left-0 right-0 flex justify-center">
              {banners.map((_, index) => (
                <button
                  key={index}
                  className={`h-2 w-2 rounded-full mx-1 ${index === currentBanner ? "bg-white" : "bg-white/50"}`}
                  onClick={() => setCurrentBanner(index)}
                />
              ))}
            </div>
          </div>

          {/* Product Banners */}
          <section className="mb-6">
            <div className="space-y-4">
              {productBanners.map((banner) => (
                <Link href={banner.link} key={banner.id}>
                  <div className={`relative rounded-lg overflow-hidden h-32 ${banner.color}`}>
                    <div className="absolute inset-0 flex items-center justify-between p-4">
                      <div className="text-white">
                        <h3 className="text-xl font-bold">{banner.title}</h3>
                        <p className="text-sm">{banner.description}</p>
                      </div>
                      <div className="relative h-24 w-24">
                        <Image
                          src={banner.image || "/placeholder.svg"}
                          alt={banner.title}
                          fill
                          className="object-contain"
                        />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>

          {/* Featured Products */}
          <section className="mb-6">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-lg font-semibold">Featured Products</h2>
              <Link href="/products/all-products" className="text-[#40E0D0] text-sm flex items-center">
                See All <ChevronRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {featuredProducts.map((product) => (
                <Link href={`/product/${product.id}`} key={product.id}>
                  <div className="bg-white rounded-lg shadow-sm overflow-hidden flex">
                    <div className="relative h-24 w-24 flex-shrink-0">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                      {product.discount && (
                        <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
                          {product.discount}
                        </div>
                      )}
                    </div>
                    <div className="p-3 flex-1">
                      <h3 className="font-medium text-sm">{product.name}</h3>
                      <p className="text-[#DEA818] font-bold mt-1">
                        {currency.symbol}
                        {product.price.toFixed(2)}
                      </p>
                      <div className="mt-1 flex items-center">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <span key={i} className="text-yellow-400 text-xs">
                              ★
                            </span>
                          ))}
                        </div>
                        <span className="text-xs text-gray-500 ml-1">(120)</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>

          {/* Categories */}
          <section className="mb-6">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-lg font-semibold">Categories</h2>
              <Link href="/category/all" className="text-[#40E0D0] text-sm flex items-center">
                See All <ChevronRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="grid grid-cols-4 gap-3">
              {categories.slice(0, 8).map((category) => (
                <Link href={category.path} key={category.name}>
                  <div className="flex flex-col items-center">
                    <div className="relative h-16 w-16 mb-1 bg-white rounded-full overflow-hidden border border-gray-200">
                      <Image
                        src={category.image || "/placeholder.svg"}
                        alt={category.name}
                        fill
                        className="object-cover p-2"
                      />
                    </div>
                    <span className="text-xs text-center">{category.name}</span>
                  </div>
                </Link>
              ))}
            </div>
          </section>

          {/* Flash Deals */}
          <section className="mb-6">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-lg font-semibold">Flash Deals</h2>
              <Link href="/products/flash-deals" className="text-[#40E0D0] text-sm flex items-center">
                See All <ChevronRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="overflow-x-auto">
              <div className="flex space-x-3 pb-2 w-max">
                {flashDeals.map((deal) => (
                  <Link href={`/product/${deal.id}`} key={deal.id}>
                    <div className="bg-white rounded-lg shadow-sm overflow-hidden w-40">
                      <div className="relative h-40 w-40">
                        <Image src={deal.image || "/placeholder.svg"} alt={deal.name} fill className="object-cover" />
                        <div className="absolute top-2 left-2 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
                          {deal.discount}
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-1 py-0.5 rounded">
                          {deal.timeLeft}
                        </div>
                      </div>
                      <div className="p-2">
                        <h3 className="font-medium text-sm line-clamp-1">{deal.name}</h3>
                        <div className="flex items-center mt-1">
                          <span className="text-[#DEA818] font-bold">
                            {currency.symbol}
                            {deal.discountedPrice.toFixed(2)}
                          </span>
                          <span className="text-gray-400 text-xs line-through ml-1">
                            {currency.symbol}
                            {deal.originalPrice.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>

          {/* Recommended Products */}
          <section>
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-lg font-semibold">Recommended For You</h2>
              <Link href="/products/recommended" className="text-[#40E0D0] text-sm flex items-center">
                See All <ChevronRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[...Array(8)].map((_, index) => (
                <Link href={`/product/${200 + index}`} key={index}>
                  <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div className="relative h-36 w-full">
                      <Image
                        src={`/placeholder.svg?height=150&width=150&text=Product+${index + 1}`}
                        alt={`Product ${index + 1}`}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="p-2">
                      <h3 className="font-medium text-sm line-clamp-1">Product Name {index + 1}</h3>
                      <p className="text-[#DEA818] font-bold mt-1">
                        {currency.symbol}
                        {(19.99 + index * 10).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        </main>

        {/* Floating Chat Support Button */}
        <button
          onClick={() => setShowChatSupport(true)}
          className="fixed bottom-20 right-4 bg-[#DEA818] text-white rounded-full p-3 shadow-lg z-10"
        >
          <MessageSquare className="h-6 w-6" />
        </button>

        {/* Voice Search Modal */}
        {showVoiceSearch && <VoiceSearch onClose={() => setShowVoiceSearch(false)} />}

        {/* Camera Search Modal */}
        {showCameraSearch && <CameraSearch onClose={() => setShowCameraSearch(false)} />}

        {/* AI Chat Support Modal */}
        {showChatSupport && <AIChatSupport onClose={() => setShowChatSupport(false)} />}

        <MobileNavigation activeTab={activeTab} onTabChange={handleTabChange} />
      </div>
    </CurrencyContext.Provider>
  )
}

