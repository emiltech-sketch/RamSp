"use client"

import { Home, Grid, ShoppingCart, User, HelpCircle } from "lucide-react"
import { useCart } from "@/components/cart-provider"

interface MobileNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export default function MobileNavigation({ activeTab, onTabChange }: MobileNavigationProps) {
  const { cart } = useCart()

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-10">
      <div className="flex justify-around py-2">
        <button
          className={`flex flex-col items-center px-3 py-1 ${
            activeTab === "home" ? "text-[#33998D]" : "text-gray-600"
          }`}
          onClick={() => onTabChange("home")}
        >
          <Home className={`h-5 w-5 ${activeTab === "home" ? "text-[#33998D]" : "text-gray-600"}`} />
          <span className="text-xs mt-1">Home</span>
        </button>

        <button
          className={`flex flex-col items-center px-3 py-1 ${
            activeTab === "categories" ? "text-[#33998D]" : "text-gray-600"
          }`}
          onClick={() => onTabChange("categories")}
        >
          <Grid className={`h-5 w-5 ${activeTab === "categories" ? "text-[#33998D]" : "text-gray-600"}`} />
          <span className="text-xs mt-1">Categories</span>
        </button>

        <button
          className={`flex flex-col items-center px-3 py-1 relative ${
            activeTab === "cart" ? "text-[#33998D]" : "text-gray-600"
          }`}
          onClick={() => onTabChange("cart")}
        >
          <ShoppingCart className={`h-5 w-5 ${activeTab === "cart" ? "text-[#33998D]" : "text-gray-600"}`} />
          {cart.length > 0 && (
            <span className="absolute -top-1 right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              {cart.length}
            </span>
          )}
          <span className="text-xs mt-1">Cart</span>
        </button>

        <button
          className={`flex flex-col items-center px-3 py-1 ${
            activeTab === "account" ? "text-[#33998D]" : "text-gray-600"
          }`}
          onClick={() => onTabChange("account")}
        >
          <User className={`h-5 w-5 ${activeTab === "account" ? "text-[#33998D]" : "text-gray-600"}`} />
          <span className="text-xs mt-1">Account</span>
        </button>

        <button
          className={`flex flex-col items-center px-3 py-1 ${
            activeTab === "help" ? "text-[#33998D]" : "text-gray-600"
          }`}
          onClick={() => onTabChange("help")}
        >
          <HelpCircle className={`h-5 w-5 ${activeTab === "help" ? "text-[#33998D]" : "text-gray-600"}`} />
          <span className="text-xs mt-1">Help</span>
        </button>
      </div>
    </div>
  )
}

