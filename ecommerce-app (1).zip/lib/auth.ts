import { compare, hash } from "bcryptjs"
import { sign, verify } from "jsonwebtoken"
import { ObjectId } from "mongodb"
import clientPromise from "./mongodb"

// JWT secret should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// User type definition
export interface User {
  _id: string | ObjectId
  username: string
  email: string
  password: string
  createdAt: Date
  updatedAt: Date
}

// Get user by ID
export async function getUserById(id: string) {
  try {
    const client = await clientPromise
    const db = client.db()
    const user = await db.collection("users").findOne({ _id: new ObjectId(id) })

    if (!user) return null

    // Don't return the password
    const { password, ...userWithoutPassword } = user
    return userWithoutPassword
  } catch (error) {
    console.error("Error getting user by ID:", error)
    return null
  }
}

// Get user by email
export async function getUserByEmail(email: string) {
  try {
    const client = await clientPromise
    const db = client.db()
    return db.collection("users").findOne({ email })
  } catch (error) {
    console.error("Error getting user by email:", error)
    return null
  }
}

// Create user
export async function createUser(userData: { username: string; email: string; password: string }) {
  try {
    const client = await clientPromise
    const db = client.db()

    // Check if user already exists
    const existingUser = await getUserByEmail(userData.email)
    if (existingUser) {
      throw new Error("User already exists")
    }

    // Hash password
    const hashedPassword = await hash(userData.password, 12)

    // Create user
    const result = await db.collection("users").insertOne({
      ...userData,
      password: hashedPassword,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    // Get created user
    const user = await getUserById(result.insertedId.toString())
    return user
  } catch (error) {
    console.error("Error creating user:", error)
    throw error
  }
}

// Verify password
export async function verifyPassword(password: string, hashedPassword: string) {
  return compare(password, hashedPassword)
}

// Create token
export function createToken(payload: any) {
  return sign(payload, JWT_SECRET, { expiresIn: "7d" })
}

// Verify token
export function verifyToken(token: string) {
  try {
    return verify(token, JWT_SECRET) as { id: string }
  } catch (error) {
    console.error("Error verifying token:", error)
    return null
  }
}

