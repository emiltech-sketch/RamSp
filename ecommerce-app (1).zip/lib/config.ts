// API Keys Configuration

// Stripe Payment API Keys
export const STRIPE_PUBLISHABLE_KEY =
  "pk_test_51QtAZLRwQq5U4QS4M6slYEAKdgIjTHfMpYw5Jtt4TgKtmeCY7mNoM1wkwOjch6i8OuB6o87XQLwpNvz2ZNK1TXQE00zYW5iaM8"
export const STRIPE_SECRET_KEY =
  "sk_test_51QtAZLRwQq5U4QS49qQPOO9xFJ1dG9CcIPdbfi7uiK9fBjTyfIte4RMGmuOdj77lIU04fyqT05OzLon4CGv6rcnZ00dPY8vdRt"

// Google Maps API Key
export const GOOGLE_MAPS_API_KEY = "AIzaSyDQynpt_Gpt_I3MYYGYFe2qf-2PicCoba4"

// OpenAI API Key - Now using environment variables
export const OPENAI_API_KEY = process.env.OPENAI_API_KEY || ""

// Firebase Configuration
export const firebaseConfig = {
  apiKey: "AIzaSyDQynpt_Gpt_I3MYYGYFe2qf-2PicCoba4",
  authDomain: "ramsphere-181da.firebaseapp.com",
  projectId: "ramsphere-181da",
  storageBucket: "ramsphere-181da.firebasestorage.app",
  messagingSenderId: "241178157252",
  appId: "1:241178157252:android:8bdffa6be2130687162991",
}

