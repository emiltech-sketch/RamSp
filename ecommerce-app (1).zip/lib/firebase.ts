"use client"

import { initializeApp, getApps, getApp } from "firebase/app"
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { firebaseConfig } from "./config"

// Initialize Firebase only on the client side
let app
let auth
let db
let storage

// Check if we're in the browser environment
if (typeof window !== "undefined") {
  // Initialize Firebase only once
  app = !getApps().length ? initializeApp(firebaseConfig) : getApp()
  auth = getAuth(app)
  db = getFirestore(app)
  storage = getStorage(app)
}

// Authentication functions
export const signIn = async (email: string, password: string) => {
  if (!auth) {
    return { user: null, error: "Authentication not initialized" }
  }

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    return { user: userCredential.user, error: null }
  } catch (error: any) {
    // Provide more user-friendly error messages
    let errorMessage = "Failed to sign in. Please try again."

    if (error.code === "auth/user-not-found") {
      errorMessage = "No account found with this email. Please check your email or sign up."
    } else if (error.code === "auth/wrong-password") {
      errorMessage = "Incorrect password. Please try again or reset your password."
    } else if (error.code === "auth/invalid-email") {
      errorMessage = "Invalid email format. Please enter a valid email address."
    } else if (error.code === "auth/too-many-requests") {
      errorMessage = "Too many failed login attempts. Please try again later or reset your password."
    } else if (error.code === "auth/network-request-failed") {
      errorMessage = "Network error. Please check your internet connection and try again."
    }

    return { user: null, error: errorMessage }
  }
}

export const signUp = async (email: string, password: string) => {
  if (!auth) {
    return { user: null, error: "Authentication not initialized" }
  }

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    return { user: userCredential.user, error: null }
  } catch (error: any) {
    // Provide more user-friendly error messages
    let errorMessage = "Failed to create account. Please try again."

    if (error.code === "auth/email-already-in-use") {
      errorMessage = "This email is already in use. Please sign in or use a different email."
    } else if (error.code === "auth/invalid-email") {
      errorMessage = "Invalid email format. Please enter a valid email address."
    } else if (error.code === "auth/weak-password") {
      errorMessage = "Password is too weak. Please use a stronger password (at least 6 characters)."
    } else if (error.code === "auth/operation-not-allowed") {
      errorMessage = "Account creation is currently disabled. Please try again later."
    } else if (error.code === "auth/network-request-failed") {
      errorMessage = "Network error. Please check your internet connection and try again."
    }

    return { user: null, error: errorMessage }
  }
}

export const logOut = async () => {
  if (!auth) {
    return { success: false, error: "Authentication not initialized" }
  }

  try {
    await signOut(auth)
    return { success: true, error: null }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

// Create a function to get the auth instance
export const getFirebaseAuth = () => {
  if (typeof window !== "undefined" && !auth) {
    // Initialize Firebase if not already done
    app = !getApps().length ? initializeApp(firebaseConfig) : getApp()
    auth = getAuth(app)
    db = getFirestore(app)
    storage = getStorage(app)
  }
  return auth
}

// Create a function to get the firestore instance
export const getFirebaseFirestore = () => {
  if (typeof window !== "undefined" && !db) {
    // Initialize Firebase if not already done
    app = !getApps().length ? initializeApp(firebaseConfig) : getApp()
    auth = getAuth(app)
    db = getFirestore(app)
    storage = getStorage(app)
  }
  return db
}

// Create a function to get the storage instance
export const getFirebaseStorage = () => {
  if (typeof window !== "undefined" && !storage) {
    // Initialize Firebase if not already done
    app = !getApps().length ? initializeApp(firebaseConfig) : getApp()
    auth = getAuth(app)
    db = getFirestore(app)
    storage = getStorage(app)
  }
  return storage
}

export { app, auth, db, storage }

