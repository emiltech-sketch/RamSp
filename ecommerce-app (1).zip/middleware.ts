import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { verify } from "jsonwebtoken"

// JWT secret should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Paths that require authentication
const protectedPaths = ["/account", "/checkout", "/payment"]

// Paths that should redirect to home if already authenticated
const authPaths = ["/signin", "/signup"]

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Get token from cookies
  const token = request.cookies.get("auth-token")?.value

  // Check if user is authenticated
  const isAuthenticated = token ? verifyToken(token) : false

  // Redirect authenticated users away from auth pages
  if (isAuthenticated && authPaths.some((path) => pathname.startsWith(path))) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  // Redirect unauthenticated users away from protected pages
  if (!isAuthenticated && protectedPaths.some((path) => pathname.startsWith(path))) {
    return NextResponse.redirect(new URL("/signin", request.url))
  }

  return NextResponse.next()
}

// Verify JWT token
function verifyToken(token: string) {
  try {
    verify(token, JWT_SECRET)
    return true
  } catch {
    return false
  }
}

export const config = {
  matcher: ["/account/:path*", "/checkout/:path*", "/payment/:path*", "/signin", "/signup"],
}

